from acestreamengine.core import run
run()
