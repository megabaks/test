#include <gtk/gtk.h>
#include "interface.h"
#include "tests.h"
#include "timer.h"

#define WIDTH 300

static int number;

GtkListStore *add_tree (GtkWidget *box)
{
	GtkWidget *sw = gtk_scrolled_window_new (NULL, NULL);
	gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (sw), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
	gtk_scrolled_window_set_shadow_type (GTK_SCROLLED_WINDOW (sw), GTK_SHADOW_IN);
	gtk_box_pack_start (GTK_BOX (box), sw, TRUE, TRUE, 0);
	gtk_widget_show (sw);
	GtkWidget *tree = gtk_tree_view_new ();
	gtk_tree_view_set_headers_visible (GTK_TREE_VIEW (tree), FALSE);
	gtk_tree_view_set_rules_hint (GTK_TREE_VIEW (tree), TRUE);
	GtkTreeViewColumn *col = gtk_tree_view_column_new ();
	gtk_tree_view_append_column (GTK_TREE_VIEW (tree), col);
	GtkListStore *list = gtk_list_store_new (1, G_TYPE_STRING);
	gtk_tree_view_set_model (GTK_TREE_VIEW (tree), GTK_TREE_MODEL (list));
	GtkCellRenderer *cell = gtk_cell_renderer_text_new ();
	gtk_tree_view_column_pack_start (GTK_TREE_VIEW_COLUMN (col), GTK_CELL_RENDERER (cell), TRUE);
	gtk_tree_view_column_add_attribute (col, cell, "markup", 0);
	gtk_widget_set_size_request (tree, WIDTH, -1);
	g_object_set (cell, "ypad", 6, NULL);
	g_object_set (cell, "wrap-width", WIDTH-8, NULL);
	g_object_set (cell, "wrap-mode", PANGO_WRAP_WORD_CHAR, NULL);
	gtk_container_add (GTK_CONTAINER (sw), tree);
	gtk_widget_show (tree);
	return list;
}

void add_button (GtkWidget *box, const gchar *stock_id)
{
	GtkWidget *button =  gtk_button_new ();
	GtkWidget *img = gtk_image_new_from_stock (stock_id, GTK_ICON_SIZE_SMALL_TOOLBAR);
	gtk_widget_show (img);
	gtk_button_set_image (GTK_BUTTON (button), img);
	gtk_box_pack_end (GTK_BOX (box), button, FALSE, FALSE, 0);
	gtk_widget_show (button);
}

void close_dialog (GtkButton *button, gpointer dialog) 
{
	gtk_widget_destroy ((GtkWidget*) dialog);
}

GtkWidget *create_test3_dialog (int number, test_data *td)
{
	GtkWidget *dialog = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_skip_taskbar_hint (GTK_WINDOW (dialog), TRUE);
	gtk_window_set_modal (GTK_WINDOW (dialog), TRUE);
	gtk_window_set_transient_for (GTK_WINDOW (dialog), GTK_WINDOW (td->parent));
	gchar title[20];
	g_snprintf (title, 20, "Test3, window %d", number);
	gtk_window_set_title (GTK_WINDOW (dialog), title);
	gtk_container_set_border_width (GTK_CONTAINER (dialog), 12);
	gtk_window_set_resizable (GTK_WINDOW (dialog), FALSE);

	GtkWidget *vbox1 = gtk_vbox_new (FALSE, 24);
	gtk_container_add (GTK_CONTAINER (dialog), vbox1);
	gtk_widget_show (vbox1);
	GtkWidget *hbox1 = gtk_hbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (vbox1), hbox1, TRUE, TRUE, 0);
	gtk_widget_show (hbox1);

	GtkWidget *vbox2 = gtk_vbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (hbox1), vbox2, TRUE, TRUE, 0);
	gtk_widget_show (vbox2);
	GtkWidget *label = gtk_label_new ("<b>Section One</b>");
	gtk_label_set_use_markup (GTK_LABEL (label), TRUE);
	gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
	gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, FALSE, 0);
	gtk_widget_show (label);
	GtkWidget *alignment = gtk_alignment_new (0.5, 0.5, 1, 1);
	gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 0, 0, 18, 0);
	gtk_widget_show (alignment);
	gtk_box_pack_start (GTK_BOX (vbox2), alignment, TRUE, TRUE, 0);
	GtkWidget *vbox3 = gtk_vbox_new (FALSE, 6);
	gtk_container_add (GTK_CONTAINER (alignment), vbox3);
	gtk_widget_show (vbox3);
	GtkWidget *hbox2 = gtk_hbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (vbox3), hbox2, TRUE, TRUE, 0);
	gtk_widget_show (hbox2);
	GtkWidget *sw = gtk_scrolled_window_new (NULL, NULL);
	gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (sw), GTK_POLICY_NEVER, GTK_POLICY_NEVER);
	gtk_scrolled_window_set_shadow_type (GTK_SCROLLED_WINDOW (sw), GTK_SHADOW_IN);
	gtk_box_pack_start (GTK_BOX (hbox2), sw, FALSE, FALSE, 0);
	gtk_widget_show (sw);
	GtkListStore *list1 = gtk_list_store_new (2, G_TYPE_STRING, G_TYPE_STRING);
	GtkWidget *tree1 = gtk_tree_view_new_with_model (GTK_TREE_MODEL (list1));
	gtk_tree_view_set_headers_visible (GTK_TREE_VIEW (tree1), FALSE);
	GtkTreeViewColumn *col1 = gtk_tree_view_column_new ();
	gtk_tree_view_append_column (GTK_TREE_VIEW (tree1), col1);
	GtkCellRenderer *cell1 = gtk_cell_renderer_pixbuf_new ();
	gtk_tree_view_column_pack_start (GTK_TREE_VIEW_COLUMN (col1), GTK_CELL_RENDERER (cell1), FALSE);
	gtk_tree_view_column_add_attribute (col1, cell1, "stock-id", 0);
	GtkTreeViewColumn *col2 = gtk_tree_view_column_new ();
	gtk_tree_view_append_column (GTK_TREE_VIEW (tree1), col2);
	GtkCellRenderer *cell2 = gtk_cell_renderer_text_new ();
	gtk_tree_view_column_pack_start (GTK_TREE_VIEW_COLUMN (col2), GTK_CELL_RENDERER (cell2), TRUE);
	gtk_tree_view_column_add_attribute (col2, cell2, "text", 1);
	gtk_tree_view_set_model (GTK_TREE_VIEW (tree1), GTK_TREE_MODEL (list1));
	GtkTreeIter iter;
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_OPEN, 1, "First", -1);
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_SAVE, 1, "Second", -1);
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_OK, 1, "Third", -1);
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_CANCEL, 1, "Fourth", -1);
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_CLOSE, 1, "Fifth", -1);
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_APPLY, 1, "Sixth", -1);
	gtk_list_store_append (list1, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list1), &iter, 0, GTK_STOCK_QUIT, 1, "Seventh", -1);
	gtk_container_add (GTK_CONTAINER (sw), tree1);
	g_object_set (cell1, "ypad", 12, NULL);
	gtk_widget_show (tree1);
	
	GtkListStore *list2 = add_tree (hbox2);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>First item on the left</b>\n"
	                                                      "<small>Description number one</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Second item on the left</b>\n"
	                                                      "<small>Description number two</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Third item on the left</b>\n"
	                                                      "<small>Description number three</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Fourth item on the left</b>\n"
	                                                      "<small>Description number four</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Fifth item on the left</b>\n"
	                                                      "<small>Description number five</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Sixth item on the left</b>\n"
	                                                      "<small>Description number six</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Seventh item on the left</b>\n"
	                                                      "<small>Description number seven</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Eighth item on the left</b>\n"
	                                                      "<small>Description number eight</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Ninth item on the left</b>\n"
	                                                      "<small>Description number nine</small>", -1);
	gtk_list_store_append (list2, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list2), &iter, 0, "<b>Tenth item on the left</b>\n"
	                                                      "<small>Description number ten</small>", -1);

	GtkWidget *hbox3 = gtk_hbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (vbox3), hbox3, FALSE, FALSE, 0);
	gtk_widget_show (hbox3);
	add_button (hbox3, GTK_STOCK_ADD);

	GtkWidget *vbox4 = gtk_vbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (hbox1), vbox4, TRUE, TRUE, 0);
	gtk_widget_show (vbox4);
	label = gtk_label_new ("<b>Section Two</b>");
	gtk_label_set_use_markup (GTK_LABEL (label), TRUE);
	gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
	gtk_box_pack_start (GTK_BOX (vbox4), label, FALSE, FALSE, 0);
	gtk_widget_show (label);
	alignment = gtk_alignment_new (0.5, 0.5, 1, 1);
	gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 0, 0, 18, 0);
	gtk_widget_show (alignment);
	gtk_box_pack_start (GTK_BOX (vbox4), alignment, TRUE, TRUE, 0);
	GtkWidget *vbox5 = gtk_vbox_new (FALSE, 6);
	gtk_container_add (GTK_CONTAINER (alignment), vbox5);
	gtk_widget_show (vbox5);
	GtkListStore *list3 = add_tree (vbox5);
	gtk_list_store_append (list3, &iter);
	gtk_list_store_set (GTK_LIST_STORE (list3), &iter, 0, "<b>First item on the right</b>\n"
	                                                      "<small>Description number one</small>", -1);
	GtkWidget *hbox4 = gtk_hbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (vbox4), hbox4, FALSE, FALSE, 0);
	gtk_widget_show (hbox4);
	add_button (hbox4, GTK_STOCK_REMOVE);
	add_button (hbox4, GTK_STOCK_GO_DOWN);
	add_button (hbox4, GTK_STOCK_GO_UP);
	add_button (hbox4, GTK_STOCK_SAVE);
	add_button (hbox4, GTK_STOCK_OPEN);

	GtkWidget *hbox5 = gtk_hbox_new (FALSE, 6);
	gtk_box_pack_start (GTK_BOX (vbox1), hbox5, FALSE, FALSE, 0);
	gtk_widget_show (hbox5);
	GtkWidget *button_close = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
	gtk_box_pack_end (GTK_BOX (hbox5), button_close, FALSE, FALSE, 0);
	gtk_widget_show (button_close);
	g_signal_connect (button_close, "clicked", G_CALLBACK (close_dialog), (gpointer) dialog);

	return dialog;
}

gboolean dialog_test (gpointer data)
{
	test_data *td = (test_data*) data;
	if (number%2 == 0)
	{
		td->dialog = create_test3_dialog (number/2 + 1, td);
		gtk_widget_show (td->dialog);
	}
	else
	{
		if (number < (td->cycles-1)*2)
		{
			gtk_widget_destroy (td->dialog);
		}
		else
		{
			if (!td->keep)
				gtk_widget_destroy ((GtkWidget*) td->dialog);
			write_time (td->label, timer_stop ());
			g_free (td);
			return FALSE;
		}
	}
	number++;
	return TRUE;
}

void test3 (test_data *td)
{
	number = 0;
	timer_start ();
	g_idle_add (dialog_test, td);
}
