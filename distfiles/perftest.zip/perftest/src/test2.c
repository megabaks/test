#include <gtk/gtk.h>
#include "interface.h"
#include "tests.h"
#include "timer.h"

#define WIDGET1 gtk_spin_button_new_with_range (0, 100, 1)
#define WIDGET2 gtk_hscale_new_with_range (0, 100, 10)
//#define WIDGET2 gtk_button_new_from_stock (GTK_STOCK_APPLY)
//#define WIDGET2 gtk_radio_button_new (NULL)
#define COLUMNS 3
#define ROWS 10

static GtkWidget *notebook;

void add_tab (gint number)
{
	GtkWidget *sb; //the benchmarked widget
	GtkWidget *hbox, *label;

	GtkWidget *vbox = gtk_vbox_new (FALSE, 6);
	gtk_container_set_border_width (GTK_CONTAINER (vbox), 12);

	int i;
	for (i=0; i<ROWS; i++)
	{
		hbox = gtk_hbox_new (FALSE, 12);
		gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, FALSE, 0);
		int j;
		for (j=0; j<COLUMNS; j++)
		{
			if (number == 1)
				sb = WIDGET1;
			else
				sb = WIDGET2;
			gtk_box_pack_start (GTK_BOX (hbox), sb, TRUE, TRUE, 0);
		}
	}

	gchar text[11];
	g_snprintf (text, 11, "Widgets %d", number);
	label = gtk_label_new (text);
	gtk_notebook_append_page (GTK_NOTEBOOK (notebook), vbox, label);
}

GtkWidget* create_test2_dialog (test_data *td)
{
	GtkWidget *window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_modal (GTK_WINDOW (window), TRUE);
	gtk_window_set_transient_for (GTK_WINDOW (window), GTK_WINDOW (td->parent));
	gtk_window_set_title (GTK_WINDOW (window), "Test 2");
	gtk_container_set_border_width (GTK_CONTAINER (window), 12);
	gtk_window_set_resizable (GTK_WINDOW (window), FALSE);

	notebook = gtk_notebook_new ();
	gtk_container_add (GTK_CONTAINER (window), notebook);

	add_tab (1);
	add_tab (2);

	gtk_widget_show_all (window);
	return window;
}

gboolean tab_test (gpointer data)
{
	test_data *td = (test_data*) data;
	gtk_notebook_set_current_page (GTK_NOTEBOOK (notebook), td->cycles % 2);
	if (--td->cycles > 0)
	{
		return TRUE;
	}
	else
	{
		if (!td->keep)
			gtk_widget_destroy ((GtkWidget*) td->dialog);
		write_time (td->label, timer_stop ());
		g_free (td);
		return FALSE;
	}
}

void test2 (test_data *td)
{
	td->dialog = create_test2_dialog (td);
	timer_start ();
	g_idle_add (tab_test, td);
}