void timer_start (void);
double timer_stop (void);
