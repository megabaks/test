#include <gtk/gtk.h>
#include "timer.h"
#include "interface.h"

int main (int argc, char **argv)
{
	timer_start ();
	gtk_init (&argc, &argv);
	create_main_window ();
	write_startup_time (timer_stop ());
	gtk_main ();
}
