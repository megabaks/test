#include <gtk/gtk.h>
#include "interface.h"
#include "tests.h"
#include "timer.h"

static GtkWidget *window;
static GtkWidget *status;
static GtkWidget *checkbutton_keep;
static callback_data cd1, cd2, cd3;

void write_time (GtkWidget *label, double tm)
{
	gchar seconds[8];
	g_snprintf (seconds, 8, "%f", tm);
	gchar *time = g_strconcat ("Time: <b>", seconds, " s</b>", NULL);
	gtk_label_set_markup (GTK_LABEL (label), time);
	g_free (time);
}

void write_startup_time (double tm)
{
	gchar seconds[8];
	g_snprintf (seconds, 8, "%f", tm);
	gchar *msg = g_strconcat ("Startup time: ", seconds, " s", NULL);
	gtk_statusbar_push (GTK_STATUSBAR (status), 0, msg);
	g_free (msg);
}

void call_test (GtkWidget *button, gpointer data)
{
	callback_data *cd = (callback_data*) data;
	test_data *td = g_new (test_data, 1);
	td->cycles = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (cd->spin));
	td->keep = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (checkbutton_keep));
	td->parent = window;
	td->label = cd->label;
	cd->call (td);
}

void *add_test (GtkWidget *box, gint number, gchar *text, callback_data *cd, gint cycles)
{
	GtkWidget *vbox1 = gtk_vbox_new (FALSE, 0);
	gtk_box_pack_start (GTK_BOX (box), vbox1, FALSE, FALSE, 0);
	gtk_widget_show (vbox1);
	gchar n[5];
	g_snprintf (n, 5, "%d", number);
	gchar *heading = g_strconcat ("<span weight=\"bold\">Test ", n, "</span>", NULL);
	GtkWidget *label = gtk_label_new (heading);
	g_free (heading);
	gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
	gtk_label_set_use_markup (GTK_LABEL (label), TRUE);
	gtk_box_pack_start (GTK_BOX (vbox1), label, FALSE, FALSE, 0);
	gtk_widget_show (label);
	GtkWidget *alignment = gtk_alignment_new (0, 0, 1, 1);
	gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 6, 0, 18, 0);
	gtk_box_pack_start (GTK_BOX (vbox1), alignment, FALSE, FALSE, 0);
	gtk_widget_show (alignment);
	GtkWidget *vbox2 = gtk_vbox_new (FALSE, 6);
	gtk_container_add (GTK_CONTAINER (alignment), vbox2);
	gtk_widget_show (vbox2);
	GtkWidget *hbox = gtk_hbox_new (FALSE, 12);
	gtk_box_pack_start (GTK_BOX (vbox2), hbox, FALSE, FALSE, 0);
	gtk_widget_show (hbox);
	GtkWidget *button = gtk_button_new_from_stock (GTK_STOCK_EXECUTE);
	gtk_box_pack_start (GTK_BOX (hbox), button, FALSE, FALSE, 0);
	gtk_widget_show (button);
	label = gtk_label_new (text);
	gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, FALSE, 0);
	gtk_widget_show (label);
	cd->spin = gtk_spin_button_new_with_range (1, 5000, 1);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (cd->spin), cycles);
	gtk_box_pack_start (GTK_BOX (hbox), cd->spin, FALSE, FALSE, 0);
	gtk_widget_show (cd->spin);
	label = gtk_label_new ("times");
	gtk_box_pack_start (GTK_BOX (hbox), label, FALSE, TRUE, 0);
	gtk_widget_show (label);
	cd->label = gtk_label_new ("Time:");
	gtk_label_set_selectable (GTK_LABEL (cd->label), TRUE);
	gtk_misc_set_alignment (GTK_MISC (cd->label), 0, 0.5);
	gtk_box_pack_start (GTK_BOX (vbox2), cd->label, FALSE, FALSE, 0);
	gtk_widget_show (cd->label);
	g_signal_connect (button, "clicked", G_CALLBACK (call_test), (gpointer) cd);
}

void create_main_window (void)
{
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window), "perftest");
	gtk_container_set_border_width (GTK_CONTAINER (window), 12);
	gtk_window_set_resizable (GTK_WINDOW (window), FALSE);

	GtkWidget *vbox1 = gtk_vbox_new (FALSE, 12);
	gtk_container_add (GTK_CONTAINER (window), vbox1);
	gtk_widget_show (vbox1);
	
	checkbutton_keep = gtk_check_button_new_with_mnemonic ("_Keep the test window open");
	gtk_box_pack_start (GTK_BOX (vbox1), checkbutton_keep, FALSE, FALSE, 0);
	gtk_widget_show (checkbutton_keep);

	GtkWidget *vbox2 = gtk_vbox_new (FALSE, 12);
	gtk_box_pack_start (GTK_BOX (vbox1), vbox2, TRUE, TRUE, 0);
	gtk_widget_show (vbox2);

	cd1.call = test1;
	cd2.call = test2;
	cd3.call = test3;
	add_test (vbox2, 1, "Cycle through items in a combo box", &cd1, 50);
	add_test (vbox2, 2, "Switch between tabs with spin buttons and sliders", &cd2, 100);
	add_test (vbox2, 3, "Open a three-pane dialog", &cd3, 50);

	status = gtk_statusbar_new ();
	gtk_box_pack_start (GTK_BOX (vbox1), status, FALSE, FALSE, 0);
	gtk_widget_show (status);
	g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	gtk_widget_show (window);
}
