#include <sys/time.h>
#include <stddef.h>
#include "timer.h"

static struct timeval start, end;

void timer_start (void)
{
	gettimeofday (&start, NULL);
}

double timer_stop (void)
{
	gettimeofday (&end, NULL);
	double endtime = end.tv_sec + end.tv_usec/1000000.0;
	double starttime = start.tv_sec + start.tv_usec/1000000.0;
	return endtime - starttime;
}
