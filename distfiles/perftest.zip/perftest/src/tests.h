void test1 (test_data *td);
void test2 (test_data *td);
void test3 (test_data *td);
