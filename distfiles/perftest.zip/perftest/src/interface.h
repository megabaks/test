void create_main_window (void);
void write_time (GtkWidget *label, double tm);
void write_startup_time (double tm);

typedef struct {
	gint cycles;
	gboolean keep;
	GtkWidget *dialog;
	GtkWidget *parent;
	GtkWidget *label;
} test_data;

typedef void (*test_func) (test_data *td);

typedef struct {
	GtkWidget *spin;
	GtkWidget *label;
	test_func call;
} callback_data;