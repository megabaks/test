#include <gtk/gtk.h>
#include "interface.h"
#include "tests.h"
#include "timer.h"

static GtkWidget *combo;
static int step;

void add_item (GtkListStore *list, const char *stock_id, const char *text)
{
	GtkTreeIter iter;
	gtk_list_store_append (list, &iter);
	gtk_list_store_set (list, &iter, 0, stock_id, 1, text, -1);
}

GtkWidget *create_test1_dialog (test_data *td)
{
	GtkWidget *window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (window), "Test 1");
	gtk_window_set_modal (GTK_WINDOW (window), TRUE);
	gtk_window_set_transient_for (GTK_WINDOW (window), GTK_WINDOW (td->parent));
	gtk_container_set_border_width (GTK_CONTAINER (window), 12);
	gtk_window_set_resizable (GTK_WINDOW (window), FALSE);

	GtkListStore *list = gtk_list_store_new (2, G_TYPE_STRING, G_TYPE_STRING);
	combo = gtk_combo_box_new_with_model (GTK_TREE_MODEL (list));
	GtkCellRenderer *cell1 = gtk_cell_renderer_pixbuf_new ();
	GtkCellRenderer *cell2 = gtk_cell_renderer_text_new ();
	gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo), cell1, FALSE);
	gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo), cell1, "stock-id", 0, NULL);
	gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo), cell2, TRUE);
	gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo), cell2, "text", 1, NULL);
	add_item (list, GTK_STOCK_OPEN, "First item");
	add_item (list, GTK_STOCK_SAVE, "Second item");
	add_item (list, GTK_STOCK_OK, "Third item");
	add_item (list, GTK_STOCK_CANCEL, "Fourth item");
	add_item (list, GTK_STOCK_HOME, "Fifth item");
	add_item (list, GTK_STOCK_ADD, "Sixth item");
	add_item (list, GTK_STOCK_REMOVE,"Seventh item");
	add_item (list, GTK_STOCK_FIND, "Eighth item");
	add_item (list, GTK_STOCK_CLOSE, "Ninth item");
	add_item (list, GTK_STOCK_STOP, "Tenth item");

	gtk_container_add (GTK_CONTAINER (window), combo);
	gtk_widget_show (combo);
	gtk_widget_show (window);

	return window;
}

gboolean combo_test (gpointer data)
{
	test_data *td = (test_data*) data;
	if (step%12 == 0)
	{
			gtk_combo_box_popup (GTK_COMBO_BOX (combo));
	}
	if ((step+1) % 12 == 0)
	{
		gtk_combo_box_popdown (GTK_COMBO_BOX (combo));
	}
	else
	{
		gtk_combo_box_set_active (GTK_COMBO_BOX (combo), step%12 - 1);
	}
	step++;
	if (step/12 < td->cycles)
	{
		return TRUE;
	}
	else
	{
		if (!td->keep)
			gtk_widget_destroy ((GtkWidget*) td->dialog);
		write_time (td->label, timer_stop ());
		g_free (td);
		return FALSE;
	}
}

void test1 (test_data *td)
{
	step = 0;
	td->dialog = create_test1_dialog (td);
	timer_start ();
	g_idle_add (combo_test, td);
}
