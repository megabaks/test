<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>The following people have contributed with translations:</source>
        <translation>Следующие люди внесли вклад своими переводами:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="174"/>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="175"/>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="249"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 и %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="183"/>
        <source>Simplified-Chinese</source>
        <translation>Упрощённый китайский</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version 1.0&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot;&gt;&lt;p&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot; style=&quot;vertical-align: top;&quot; /&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Версия 1.0&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot;&gt;&lt;p&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot; style=&quot;vertical-align: top;&quot; /&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="246"/>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="185"/>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version 1.0&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Версия 1.0&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="99"/>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation>(c) ROSA 2011-2012

Проигрыватель ROSA Media Player является свободным программным обеспечением.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="191"/>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="199"/>
        <source>Portuguese - Brazil</source>
        <translation>Португальский (Бразилия)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="200"/>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Turkish</source>
        <translation>Турецкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Traditional Chinese</source>
        <translation>Китайский традиционный</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Portuguese - Portugal</source>
        <translation>Португальский (Португалия)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Greek</source>
        <translation>Греческий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="214"/>
        <source>Finnish</source>
        <translation>Финский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="267"/>
        <location filename="../about.cpp" line="279"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="303"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>About ROSA Media Player</source>
        <translation>О ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../about.ui" line="84"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="215"/>
        <source>Korean</source>
        <translation>Корейский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="216"/>
        <source>Macedonian</source>
        <translation>Македонский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="217"/>
        <source>Basque</source>
        <translation>Баскский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>Using MPlayer %1</source>
        <translation>Используется MPlayer %1</translation>
    </message>
    <message>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free sotware.</source>
        <translation type="obsolete">(c) ROSA 2011-2012

Проигрыватель ROSA Media Player является свободным программным обеспечением.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="100"/>
        <source>terms of use</source>
        <translation>условия использования</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="122"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation>Это свободное программное обеспечение; вы можете использовать, распространять и/или изменять его, руководствуясь 3-ей или (на ваше усмотрение) любой более поздней версией &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt;, если она уже официально опубликована фондом &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="218"/>
        <source>Catalan</source>
        <translation>Каталонский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="219"/>
        <source>Slovenian</source>
        <translation>Словенский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="220"/>
        <source>Arabic</source>
        <translation>Арабский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="221"/>
        <source>Kurdish</source>
        <translation>Курдский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="222"/>
        <source>Galician</source>
        <translation>Галийский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="252"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 и %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 и %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="223"/>
        <source>Vietnamese</source>
        <translation>Вьетнамский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="93"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Версия %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="224"/>
        <source>Estonian</source>
        <translation>Эстонский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="225"/>
        <source>Lithuanian</source>
        <translation>Литовский</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="213"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="213"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="213"/>
        <source>Shortcut</source>
        <translation>Горячая клавиша</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="215"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="218"/>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="464"/>
        <location filename="../actionseditor.cpp" line="523"/>
        <source>Key files</source>
        <translation>Горячие клавиши</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="462"/>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="476"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="477"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="522"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="491"/>
        <location filename="../actionseditor.cpp" line="531"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="492"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранен</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="532"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Файл не может быть загружен</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="222"/>
        <source>&amp;Change shortcut...</source>
        <translation>Изменить &amp;сочетание клавиш...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="74"/>
        <source>Audio Equalizer</source>
        <translation>Аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="77"/>
        <source>31.25 Hz</source>
        <translation>31.25 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>62.50 Hz</source>
        <translation>62.50 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="79"/>
        <source>125.0 Hz</source>
        <translation>125.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="80"/>
        <source>250.0 Hz</source>
        <translation>250.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>500.0 Hz</source>
        <translation>500.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>1.000 kHz</source>
        <translation>1.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>2.000 kHz</source>
        <translation>2.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>4.000 kHz</source>
        <translation>4.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>8.000 kHz</source>
        <translation>8.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>16.00 kHz</source>
        <translation>16.00 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>&amp;Apply</source>
        <translation>&amp;Применить</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>&amp;Set as default values</source>
        <translation>Сохранить как &amp;настройки по умолчанию</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать данные настройки по умолчанию для новых файлов.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="96"/>
        <source>Set all controls to zero.</source>
        <translation>Установить все значения в ноль.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="117"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="118"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Текущие параметры были сохранены как используемые по умолчанию.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1414"/>
        <source>&amp;File...</source>
        <translation>&amp;Файл...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1415"/>
        <source>D&amp;irectory...</source>
        <translation>Ката&amp;лог...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1416"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Список...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1419"/>
        <source>&amp;DVD from drive</source>
        <translation>DVD с &amp;привода</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1420"/>
        <source>D&amp;VD from folder...</source>
        <translation>DVD из &amp;папки...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>&amp;URL...</source>
        <translation>А&amp;дрес...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1436"/>
        <source>P&amp;lay</source>
        <translation>&amp;Воспроизведение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1442"/>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1444"/>
        <source>&amp;Frame step</source>
        <translation>По&amp;кадрово</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1455"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Нормальная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1456"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Половинная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1457"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Удвоенная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1458"/>
        <source>Speed &amp;-10%</source>
        <translation>Скорос&amp;ть –10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1459"/>
        <source>Speed &amp;+10%</source>
        <translation>Скорост&amp;ь +10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1603"/>
        <source>Sp&amp;eed</source>
        <translation>Ск&amp;орость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>&amp;Fullscreen</source>
        <translation>Н&amp;а весь экран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>&amp;Screenshot</source>
        <translation>С&amp;нимок экрана</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1478"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Постобработка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1479"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Автоопределение фазы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1480"/>
        <source>&amp;Deblock</source>
        <translation>Смазывание границ &amp;квадратов</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1481"/>
        <source>De&amp;ring</source>
        <translation>Удаление к&amp;раевых артефактов</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1482"/>
        <source>Add n&amp;oise</source>
        <translation>Добавление &amp;шума</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1625"/>
        <source>F&amp;ilters</source>
        <translation>Ф&amp;ильтры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>&amp;Mute</source>
        <translation>Выключит&amp;ь звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="258"/>
        <source>Play list</source>
        <translation>Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1491"/>
        <source>Volume &amp;-</source>
        <translation>Г&amp;ромкость –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1492"/>
        <source>Volume &amp;+</source>
        <translation>Гр&amp;омкость +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1493"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Задержка –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1494"/>
        <source>D&amp;elay +</source>
        <translation>З&amp;адержка +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1500"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Расширенное стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке (подавление голоса)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1682"/>
        <source>&amp;Filters</source>
        <translation>&amp;Фильтры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1505"/>
        <source>&amp;Load...</source>
        <translation>Загрузить из &amp;файла...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1524"/>
        <source>Help &amp;Contents</source>
        <translation>Руководство &amp;пользователя</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1580"/>
        <source>&amp;Open</source>
        <translation>&amp;Открыть</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>&amp;Audio</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1583"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1584"/>
        <source>&amp;Browse</source>
        <translation>О&amp;бзор</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1585"/>
        <source>Op&amp;tions</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>&amp;Help</source>
        <translation>Сп&amp;равка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>&amp;Recent files</source>
        <translation>Посл&amp;едние файлы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>&amp;Clear</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1612"/>
        <source>Si&amp;ze</source>
        <translation>&amp;Размер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1621"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Удаление &quot;гребёнки&quot;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1656"/>
        <location filename="../basegui.cpp" line="2917"/>
        <source>&amp;None</source>
        <translation>&amp;Ничего</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1657"/>
        <source>&amp;Lowpass5</source>
        <translation>Lowpass&amp;5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>Linear &amp;Blend</source>
        <translation>Линейное &amp;смешивание</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1686"/>
        <source>&amp;Channels</source>
        <translation>&amp;Каналы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1691"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1692"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;Окружение 4.0</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1693"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;Окружение 5.1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1696"/>
        <source>&amp;Select</source>
        <translation>Вы&amp;брать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1701"/>
        <source>&amp;Title</source>
        <translation>&amp;Заголовок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1705"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Глава</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1709"/>
        <source>&amp;Angle</source>
        <translation>&amp;Ракурс</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2216"/>
        <source>Capture desktop...</source>
        <translation>Запись экранной презентации...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4883"/>
        <source>Video capture</source>
        <translation>Запись экранной презентации</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4884"/>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation>Будет произведена запись видео с экрана. На время записи видео проигрыватель будет свернут в системный лоток. Для остановки записи нажмите на красный круглый значoк в системном лотке.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4885"/>
        <source>Start capture</source>
        <translation>Начать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4886"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1654"/>
        <source>&amp;Disabled</source>
        <translation>Запре&amp;щено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2933"/>
        <location filename="../basegui.cpp" line="2953"/>
        <location filename="../basegui.cpp" line="2973"/>
        <location filename="../basegui.cpp" line="2992"/>
        <location filename="../basegui.cpp" line="3021"/>
        <location filename="../basegui.cpp" line="3053"/>
        <location filename="../basegui.cpp" line="3080"/>
        <location filename="../basegui.cpp" line="3123"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;ничего&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3493"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3494"/>
        <location filename="../basegui.cpp" line="3723"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3495"/>
        <source>Playlists</source>
        <translation>Списки воспроизведения</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3496"/>
        <location filename="../basegui.cpp" line="3701"/>
        <location filename="../basegui.cpp" line="3724"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3491"/>
        <location filename="../basegui.cpp" line="3698"/>
        <location filename="../basegui.cpp" line="3721"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3556"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Приводы CD/DVD еще не настроены.
Вы сможете сделать это в диалоге настроек этих устройст.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3656"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3700"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4293"/>
        <source>Playing %1</source>
        <translation>Воспроизводится %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4296"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4299"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1446"/>
        <source>Play / Pause</source>
        <translation>Воспроизведение / Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>Pause / Frame step</source>
        <translation>Пауза / Покадровый просмотр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1497"/>
        <location filename="../basegui.cpp" line="1506"/>
        <source>U&amp;nload</source>
        <translation>В&amp;ыгрузить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1417"/>
        <source>V&amp;CD</source>
        <translation>&amp;Видео CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1422"/>
        <source>C&amp;lose</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1520"/>
        <source>View &amp;info and properties...</source>
        <translation>Ин&amp;формация и параметры...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>P&amp;references...</source>
        <translation>&amp;Настройки...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1546"/>
        <source>Dec volume (2)</source>
        <translation>Уменьшить громкость (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1547"/>
        <source>Inc volume (2)</source>
        <translation>Увеличить громкость (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1550"/>
        <source>Exit fullscreen</source>
        <translation>Выйти из поноэкранного режима</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1552"/>
        <source>OSD - Next level</source>
        <translation>OSD – Следующая фраза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1553"/>
        <source>Dec contrast</source>
        <translation>Уменьшить контраст</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1554"/>
        <source>Inc contrast</source>
        <translation>Повысить контраст</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1555"/>
        <source>Dec brightness</source>
        <translation>Уменьшить яркость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1556"/>
        <source>Inc brightness</source>
        <translation>Повысить яркость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1557"/>
        <source>Dec hue</source>
        <translation>Уменьшить оттенок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1558"/>
        <source>Inc hue</source>
        <translation>Повысить оттенок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1559"/>
        <source>Dec saturation</source>
        <translation>Уменьшить насыщенность</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1561"/>
        <source>Dec gamma</source>
        <translation>Уменьшить гамму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1564"/>
        <source>Next audio</source>
        <translation>Следующая звуковая дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1565"/>
        <source>Next subtitle</source>
        <translation>Следующая фраза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Next chapter</source>
        <translation>Следующий раздел</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1567"/>
        <source>Previous chapter</source>
        <translation>Предыдущий раздел</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1738"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation>ROSA Media Player – отчёт rosa-media-player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4083"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>Установленная в вашей системе версия MPlayer (%1) устарела. ROSA Media Player не может работать с ней достаточно хорошо: некотрые опции не будут работать, выбор субтитров может вызывать ошибку...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4302"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1560"/>
        <source>Inc saturation</source>
        <translation>Повысить насыщенность</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Inc gamma</source>
        <translation>Повысить гамму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1496"/>
        <source>&amp;Load external file...</source>
        <translation>За&amp;грузить из файла...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1661"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Адаптивное (mplayer)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1658"/>
        <source>&amp;Yadif (normal)</source>
        <translation>Yadif (&amp;обычный)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1659"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Yadif (удвоенная частоты кадров)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1528"/>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1529"/>
        <source>Pre&amp;vious</source>
        <translation>П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Нормализация звука</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1418"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Аудио CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1664"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Убрать шумы – &amp;обычный</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1665"/>
        <source>Denoise &amp;soft</source>
        <translation>Убрать шумы – &amp;мягкий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1663"/>
        <source>Denoise o&amp;ff</source>
        <translation>Убрать шумы – &amp;выключено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1509"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>&amp;Использовать SSA/ASS</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Двойной размер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>S&amp;ize -</source>
        <translation>Р&amp;азмер –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <source>Si&amp;ze +</source>
        <translation>Ра&amp;змер +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1483"/>
        <source>Add &amp;black borders</source>
        <translation>Добавить &amp;чёрные полосы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="260"/>
        <source>Trim video</source>
        <translation>Обрезать видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="261"/>
        <source>Extract audio track</source>
        <translation>Извлечь аудиодорожку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1484"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Про&amp;граммное масштабирование</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1510"/>
        <source>Enable &amp;closed caption</source>
        <translation>&amp;Скрытые субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Forced subtitles only</source>
        <translation>&amp;Только форсированные</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Reset video equalizer</source>
        <translation>Сброс видеоэквалайзера</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4709"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>Неожиданное завершение MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4710"/>
        <source>Exit code: %1</source>
        <translation>Код завершения: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4731"/>
        <source>MPlayer failed to start.</source>
        <translation>Ошибка запуска MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4732"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Провертье путь к MPlayer в настройках.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4736"/>
        <source>MPlayer has crashed.</source>
        <translation>Сбой MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4737"/>
        <source>See the log for more info.</source>
        <translation>Смотрите отчёт для подробной информации.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1629"/>
        <source>&amp;Rotate</source>
        <translation>По&amp;ворот</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1667"/>
        <source>&amp;Off</source>
        <translation>О&amp;тключен</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1668"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>На 90° по часовой стрелке с &amp;отражением</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1669"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>На 90° &amp;по часовой стрелке</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>На 90° п&amp;ротив часовой стрелки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1671"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>На 90° против часовой &amp;стрелки с отражением</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Show context menu</source>
        <translation>Показать контестное меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3492"/>
        <source>Multimedia</source>
        <translation>Мультимедиа</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>E&amp;qualizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Reset audio equalizer</source>
        <translation>Сброс аудиоэквалайзера</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1515"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>П&amp;оиск субтитров на OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Загрузить су&amp;бтитры на OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1644"/>
        <source>&amp;Auto</source>
        <translation>&amp;Авто</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1460"/>
        <source>Speed -&amp;4%</source>
        <translation>Скор&amp;ость –4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1461"/>
        <source>&amp;Speed +4%</source>
        <translation>Скоро&amp;сть +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1462"/>
        <source>Speed -&amp;1%</source>
        <translation>&amp;Скорость –1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>S&amp;peed +1%</source>
        <translation>С&amp;корость +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1634"/>
        <source>Scree&amp;n</source>
        <translation>&amp;Экран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Default</source>
        <translation>По &amp;умолчанию</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Next video</source>
        <translation>Следующий видеофайл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1608"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1678"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1737"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation>ROSA Media Player - отчет mplayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3555"/>
        <source>ROSA Media Player - Information</source>
        <translation>ROSA Media Player - Информация</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3777"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation>Rosa Media Player – задержка аудио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4082"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Предупреждение: Используется старая версия MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4088"/>
        <source>Please, update your MPlayer.</source>
        <translation>Пожалуйста, обновите ваш MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4090"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Это предупреждение больше не будет показано)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Next aspect ratio</source>
        <translation>Следующее соотношение сторон</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>Pre&amp;view...</source>
        <translation>Предпрос&amp;мотр...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1725"/>
        <source>DVD &amp;menu</source>
        <translation>DVD-&amp;меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>DVD &amp;previous menu</source>
        <translation>&amp;Предыдущее DVD-меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1721"/>
        <source>DVD menu, move up</source>
        <translation>DVD-меню, вверх</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1722"/>
        <source>DVD menu, move down</source>
        <translation>DVD-меню, вниз</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1723"/>
        <source>DVD menu, move left</source>
        <translation>DVD-меню, влево</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1724"/>
        <source>DVD menu, move right</source>
        <translation>DVD-меню, вправо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1726"/>
        <source>DVD menu, select option</source>
        <translation>DVD-меню, выбрать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>DVD menu, mouse click</source>
        <translation>DVD-меню, щелчок мыши</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1495"/>
        <source>Set dela&amp;y...</source>
        <translation>Установить &amp;задержку...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3778"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Задержка аудио (в миллисекундах):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4444"/>
        <source>Jump to %1</source>
        <translation>Перейти к %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>Subtitle &amp;visibility</source>
        <translation>Отобра&amp;жать субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Next wheel function</source>
        <translation>Следующая функция колеса</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1714"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>П&amp;рограмма</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1425"/>
        <location filename="../basegui.cpp" line="1426"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Редактировать...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>Next TV channel</source>
        <translation>Следующий ТВ-канал</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1430"/>
        <source>Previous TV channel</source>
        <translation>Предыдущий ТВ-канал</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1431"/>
        <source>Next radio channel</source>
        <translation>Следующий канал радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1432"/>
        <source>Previous radio channel</source>
        <translation>Предыдущий канал радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>About &amp;ROSA Media Player</source>
        <translation>О &amp;ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1594"/>
        <source>&amp;TV</source>
        <translation>&amp;ТВ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>Radi&amp;o</source>
        <translation>&amp;Радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1427"/>
        <location filename="../basegui.cpp" line="1428"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Перейти...:</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1367"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Видеофильтры отключены при использовании vdpau</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1470"/>
        <source>Fli&amp;p image</source>
        <translation>Пере&amp;вернуть картинку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Show filename on OSD</source>
        <translation>Отображать имя файла в OSD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Toggle deinterlacing</source>
        <translation>Переключить режим удаления &quot;гребёнки&quot;</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation>ROSA Media Player всё ещё запущен</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Убрать</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Восстановить</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation>Панель управления</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation>00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="99"/>
        <location filename="../controlpanel.ui" line="115"/>
        <location filename="../controlpanel.ui" line="128"/>
        <location filename="../controlpanel.ui" line="141"/>
        <location filename="../controlpanel.ui" line="154"/>
        <location filename="../controlpanel.ui" line="193"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="76"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3008"/>
        <source>Brightness: %1</source>
        <translation>Яркость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3025"/>
        <source>Contrast: %1</source>
        <translation>Контрастность: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3041"/>
        <source>Gamma: %1</source>
        <translation>Гамма: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3057"/>
        <source>Hue: %1</source>
        <translation>Оттенок: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3073"/>
        <source>Saturation: %1</source>
        <translation>Насыщенность: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3229"/>
        <source>Volume: %1</source>
        <translation>Громкость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4200"/>
        <source>Zoom: %1</source>
        <translation>Увеличение: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3368"/>
        <location filename="../core.cpp" line="3386"/>
        <source>Font scale: %1</source>
        <translation>Масштаб шрифта: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4054"/>
        <source>Aspect ratio: %1</source>
        <translation>Соотношение сторон: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4470"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Обновление кэша шрифтов. Это может занять несколько секунд...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3279"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Задержка субтитров: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3299"/>
        <source>Audio delay: %1 ms</source>
        <translation>Aудио задержка: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3138"/>
        <source>Speed: %1</source>
        <translation>Скорость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3440"/>
        <source>Subtitles on</source>
        <translation>Субтитры включены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3442"/>
        <source>Subtitles off</source>
        <translation>Субтитры отключены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4105"/>
        <source>Mouse wheel seeks now</source>
        <translation>Колесо мыши: перемотка</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4108"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Колесо мыши: громкость</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4111"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Колесо мыши: масштабироавние</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4114"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Колесо мыши: скорость</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1301"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Скриншот не получен, каталог не настроен</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1317"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Скриншоты не получены, каталог не настроен</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2727"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>Маркер &quot;A&quot; установлен в %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2747"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>Маркер &quot;B&quot; установлен в %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2765"/>
        <source>A-B markers cleared</source>
        <translation>Маркеры A-B очищены</translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation>Формат выходного файла:</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation>Версия ffmpeg, установленная на вашем компьютере, не поддерживает кодек libmp3lame. Для возможности использования функции извлечения аудиодорожки установите ffmpeg с поддержкой libmp3lame.</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation>Невозможно извлечь аудиодорожку ( возможно не хватает места на диске? )</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation>Невозможно извлечь аудиодорожку (код: %1)</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>Новый файл &quot;%1&quot; сохранен в каталоге %2</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation>Извлечь аудио</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation>Формат выходного файла:</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation>Извлечь</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="414"/>
        <source>A:%1</source>
        <translation>A:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="419"/>
        <source>B:%1</source>
        <translation>B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="362"/>
        <source>Welcome to ROSA Media Player</source>
        <translation>Добро пожаловать в Rosa Media Player</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="389"/>
        <source>&amp;Video info</source>
        <translation>Инфор&amp;мация о видео</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="390"/>
        <source>&amp;Frame counter</source>
        <translation>С&amp;чётчик кадров</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="429"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation>%1x%2 %3 кадр(а,ов)/с</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Скрыть отчёт</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Показать отчёт</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>Ошибка MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation>Значок</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation>Редактор списков избранного</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation>Список избранного</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Вы можете редактировать, удалять, сортировать и добавлять новые пункты. Двойной клик на ячейке для редактирования её содержимого.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="244"/>
        <source>Select an icon file</source>
        <translation>Выбрать файл значка</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="246"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation>&amp;Добавить</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation>Удалить &amp;все</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation>Перейти к элементу</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Введите номер элемента списка для перехода:</translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Загрузка...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Загрузка %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation>ROSA Media Player – Параметры файла</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Демультиплексор</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>В&amp;ыберите демультиплексор для воспроизведения этого файла:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>В&amp;идео</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>Вы&amp;берите видео кодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>А&amp;удио</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>Выб&amp;ерите аудио кодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>Настройки &amp;MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Дополнительные параметры Mplayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Здесь можно указать дополнительные параметры для MPlayer.
Указывайте их, разделяя пробелами.
Например: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Настройки:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Также Вы можете передать дополнительные фильтры видео.
Разделяйте их запятой. Не используйте пробелы!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Видео фильтры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Аудио фильтры. Используются аналогично видео фильтрам.
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Аудио &amp;фильтры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="79"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="80"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="81"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation>добавление шума</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation>смазывание границ квадратов</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation>нормальное понижение шумов</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation>мягкое понижение шумов</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation>нормализация громкости</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation>Http</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Включить/отключить использование прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation>Имя прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation>Порт прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Если прокси требует аутентификации, укажите имя пользователя.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Пароль для прокси. &lt;b&gt;Внимание:&lt;/b&gt; пароль будет сохранён в виде текста в конфигурационном файле.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation>Выберите тип прокси, который будет использоваться.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation>Дополнительные настройки</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Включить прокси</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation>&amp;Хост:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation>&amp;Имя пользователя:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation>&amp;Пароль:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation>&amp;Тип:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Файлы</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Загружено</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Копировать ссылку в буфер обмена</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="304"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="305"/>
        <source>Download failed: %1.</source>
        <translation>Ошибка загузки: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="310"/>
        <source>Connecting to %1...</source>
        <translation>Соединение с %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="316"/>
        <source>Downloading...</source>
        <translation>Загрузка...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="324"/>
        <source>Done.</source>
        <translation>Завершено.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="370"/>
        <source>%1 files available</source>
        <translation>%1 файлов доступно</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="379"/>
        <source>Failed to parse the received data.</source>
        <translation>Ошибка обработки полученных данных.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Найти субтитры</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Субтитры для</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Язык:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="524"/>
        <source>Subtitle saved as %1</source>
        <translation>Субтиры сохранены как %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="547"/>
        <source>%1 subtitle(s) extracted</source>
        <translation>
            <numerusform>%1 субтитр(а,ов) извлечено</numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="561"/>
        <source>Overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="562"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>Файл %1 существует, перезаписать?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="479"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="480"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Не удалось сохранить загруженный
файл в каталоге %1
Проверьте права на этот каталог.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="302"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="473"/>
        <source>Download failed</source>
        <translation>Ошибка загрузки</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="457"/>
        <source>Temporary file %1</source>
        <translation>Временный файл %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Настройки</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Основная информация</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 КБ (%2 МБ)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Продолжительность</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Демультиплексор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Исполнитель</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Дорожка</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Авторское право</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Примечание</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Программа</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Информация о клипе</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Разрешение экрана</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 кб/с</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Кадров в секунду</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Выбранный кодек</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Исходный Аудио-поток</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Звуковые дорожки</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>ничего</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>№</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Название потока</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Адрес потока</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation>Rosa Media Player – Воспроизвести DVD из каталога</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Вы можете открыть DVD с жесткого диска. Выберите каталог, содержащий VIDEO_TS и AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Обзор...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation>Rosa Media Player – укажите версию MPlayer</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation>Rosa Media Player не может определить используемую вами версию MPlayer.</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>Версия, полученная от MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Пожалуйста, &amp;выберите правильную версию:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 или старше</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 или новее</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation>Rosa Media Player – укажите адрес</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;Адрес:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>&amp;Cписок воспроизведения</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="34"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Если опция отмечена, адрес будет воспринят как список: он будет открыть как текст и будут воспроизведены адреса из него.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Абхазский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Африкаанс</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Амхарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Арабский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Ассамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Аймара</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Азербайджанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Башкирский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Бихари</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Бислама</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Бенгальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Тибетский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Бретонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Каталонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Корсиканский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Валлийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Датский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Греческий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Английский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Эсперанто</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Испанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Эстонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Баскский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Персидский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Финский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Фарерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Фризский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Ирландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Галийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Гуарани</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Гуджарати</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Хауса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Хинди</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Хорватский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Армянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Интерлингва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Индонезийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Интерлингва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Ирландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Инуктитут</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Яванский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Казахский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Гренландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Каннада</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Корейский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Кашмирский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Курдский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Киргизский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Латинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Лингала</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Литовский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Латвийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Малагасийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Маори</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Македонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Малаялам</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Монгольский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Молдавский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Маратхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Малайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Мальтийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Бирманский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Науру</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Непальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Норвежский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Окситанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Ория</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Португальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Кечуа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Киньяруанда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Санскрит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Синдхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Словенский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Шона</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Сомалийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Албанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Суданский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Суахили</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Тамил</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Телугу</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Таджикский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Тайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Тиграи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Туркменский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Тагальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Турецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Тсонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Татарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Тви</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Уйгурский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Урду</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Узбекский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Вьетнамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Волоф</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Коса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Идиш</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Йоруба</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Чжуан</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Китайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Зулусский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Португальский (Бразилия)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Португальский (Португалия)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Китайский упрощённый</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Китайский традиционный</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Юникод</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Восточноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Восточноевропейская с Евро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Славянская/центральноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Эсперанто, Галисийская, Мальтийская, Турецкая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Старая Балтийская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Кириллица</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Греческая новая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Балтийская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Кельтская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Украинская, Белорусская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Китайская упрощенная</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Китайская традиционная</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Японская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Корейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Тайская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Кириллица Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Славянская/центральноевропейская Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Арабская Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation>Авестийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation>Акан</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation>Арагонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation>Аварский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation>Белорусский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation>Бамана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation>Боснийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation>Чеченский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation>Кри</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation>Церковный</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation>Чувашский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation>Мальдивский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation>Дзонг-кэ</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation>Эве</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation>Фула</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation>Фиджийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation>Гойдельский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation>Мэнский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation>Хири-моту</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation>Гаитянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation>Гереро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation>Чаморро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation>Игбо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation>Сычуаньский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation>Инуитский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation>Идо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation>Конго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation>Кикуйю</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation>Кваньяма</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation>Кхмерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation>Канури</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation>Коми</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation>Корнский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation>Люксембургский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation>Луганда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation>Лимбургский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation>Лаосский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation>Луба-Катанга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation>Маршалльский</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Букмол</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation>Ндебеле</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation>Ндонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation>Навахо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation>Ньянджа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation>Оджибва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation>Оромо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation>Осетинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation>Панджаби</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation>Пали</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation>Пушту</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation>Романшский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation>Рунди</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation>Сардинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation>Саамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation>Санго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation>Сингальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation>Свати</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation>Сесото</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation>Тсвана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation>Таитянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation>Венда</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation>Волапюк</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation>Валлонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation>Новогреческий язык Windows</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Выберите имя файла для сохранения</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Файл уже существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Невозможно сохранить отчёт</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Отчёты</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Окно отчёта</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Копировать в буфер обмена</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="341"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="341"/>
        <source>Length</source>
        <translation>Продолжительность</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="346"/>
        <source>&amp;Play</source>
        <translation>Воспро&amp;изведение</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="382"/>
        <source>&amp;Edit</source>
        <translation>&amp;Редактировать</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="818"/>
        <location filename="../playlist.cpp" line="838"/>
        <source>Playlists</source>
        <translation>Список</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="816"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="392"/>
        <source>ROSA Media Player - Playlist</source>
        <translation>Rosa Media Player – Список</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="836"/>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="850"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="851"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1076"/>
        <source>Select one or more files to open</source>
        <translation>Выберите один или более файлов</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1140"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1355"/>
        <source>Edit name</source>
        <translation>Изменить имя</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1356"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Введите имя, которое будет соответствовать в списке этому файлу:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="343"/>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="348"/>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>Pre&amp;vious</source>
        <translation>П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="364"/>
        <source>Move &amp;up</source>
        <translation>Переместить в&amp;верх</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="365"/>
        <source>Move &amp;down</source>
        <translation>Переместить в&amp;низ</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="367"/>
        <source>&amp;Repeat</source>
        <translation>Пов&amp;торить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>S&amp;huffle</source>
        <translation>Пере&amp;мешать</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="373"/>
        <source>Add &amp;current file</source>
        <translation>Добавить &amp;текущий файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Add &amp;file(s)</source>
        <translation>Добавить &amp;файл(ы)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="375"/>
        <source>Add &amp;directory</source>
        <translation>Добавить &amp;каталог</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="378"/>
        <source>Remove &amp;selected</source>
        <translation>Убрать в&amp;ыбранные</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Remove &amp;all</source>
        <translation>Убрать в&amp;се</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="386"/>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="388"/>
        <source>Remove...</source>
        <translation>Убрать...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="880"/>
        <source>Playlist modified</source>
        <translation>Список воспроизведения изменен</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="881"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Есть несохранённые изменения, желаете сохранить список воспроизведения?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="370"/>
        <source>Preferences</source>
        <translation>Настройки</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Список – Настройки</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Выберите эту опцию, если вы хотите, чтобы при добавлении каталога подкаталоги тоже добавлялись рекурсивно. Иначе будут добавлены только файлы из текущего каталога.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>&amp;Добавлять файлы из каталогов рекурсивно</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Выберите эту опцию, чтобы извлечь из добавляемых в список файлов некоторую информацию. Это позволяет отображать имя (если доступно) и информацию о файлах. Иначе эта информация не будет доступна, пока файл не начнёт воспроизводиться. Будьте осторожны: эта опция может замедлить работу, особенно при большом количестве добавляемых файлов.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Автоматически получать &amp;сведения о добавляемых файлах</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>Сохранять &amp;копию списка воспроизведения при выходе</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>&amp;Воспроизводить файлы при запуске</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Внимание</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Не все файлы могут быть ассоциированы. Проверье свои права и попытайтесь снова.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Типы файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Выбраь все типы файлов в списке</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Ничего не выбирать в списке</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Список типов файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation>Отметьте типы файлов, которые хотите связать с ROSA Media Player. После нажатия Применить, отмеченные типы файлов будут ассоциированы с ROSA Media Player. Если убрать отметку, файловая ассоциация будет восстановлена.</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Типы файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation>Медиа файлы, ассоциированные с ROSA Media Player:</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Ничего не выбирать</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Ничего не выбирать</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation>(sp)&lt;b&gt;Примечание:&lt;/b&gt; (Восстановление ассоциаций не работает в Windows Vista).</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <location filename="../prefdrives.ui" line="27"/>
        <location filename="../prefdrives.cpp" line="72"/>
        <source>Drives</source>
        <translation>Устройства</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="60"/>
        <location filename="../prefdrives.ui" line="158"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="200"/>
        <source>CD device</source>
        <translation>CD устройство</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="201"/>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation>Выберите CD привод. Он будет использоваться для воспроизведения видео и аудио CD.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="204"/>
        <source>DVD device</source>
        <translation>DVD устройство</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="205"/>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation>Выберите ваш DVD привод. Он будет использоваться для воспроизведения DVD.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="209"/>
        <source>If this option is checked, ROSA Media Player will play DVDs using dvdnav. Requires a recent version of mplayer compiled with dvdnav support.</source>
        <translation>Если эта опция отмечена, ROSA Media Player будет воспроизводить DVD используя dvdnav. Требуется последняя версия mplayer, собранная с поддержкой dvdnav.</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="39"/>
        <source>ROSA Media Player does not choose any CDROM or DVD devices by default. So before you can actually play a CD or DVD you have to select the devices you want to use (they can be the same).</source>
        <translation>ROSA Media Player не выбирает устройства CDROM или DVD по умолчанию. Поэтому чтобы воспроизводить CD или DVD, выберите устройства, которые вы хотите использовать (они могут быть одним и тем же устройством).</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="78"/>
        <source>Select your &amp;CD device:</source>
        <translation>Выберите ваш CD &amp;привод:</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="176"/>
        <source>Select your &amp;DVD device:</source>
        <translation>Выберите ваш DVD п&amp;ривод:</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="208"/>
        <source>Enable DVD menus</source>
        <translation>Включить DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="212"/>
        <source>&lt;b&gt;Note 1&lt;/b&gt;: cache will be disabled, this can affect performance.</source>
        <translation>&lt;b&gt;Примечание 1&lt;/b&gt;: кэш будет отключен, это может повлиять на производительность.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="213"/>
        <source>&lt;b&gt;Note 2&lt;/b&gt;: you may want to assign the action &quot;activate option in DVD menus&quot; to one of the mouse buttons.</source>
        <translation>&lt;b&gt;Примечание 2&lt;/b&gt;: вы можете захотеть привязать действие &quot;активация опции в DVD-меню&quot; к одной из двух кнопок мыши.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="215"/>
        <source>&lt;b&gt;Note 3&lt;/b&gt;: this feature is under development, expect a lot of issues with it.</source>
        <translation>&lt;b&gt;Примечание 3&lt;/b&gt;: эта особенность находится в разработке, возможны различные проблемы при её использовании.</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="225"/>
        <source>&amp;Enable DVD menus (experimental)</source>
        <translation>&amp;Включить DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="122"/>
        <source>&amp;Scan for CD/DVD drives</source>
        <translation>Про&amp;верить наличие CD/DVD приводов</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="86"/>
        <location filename="../prefgeneral.cpp" line="831"/>
        <source>General</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="33"/>
        <source>&amp;General</source>
        <translation>&amp;Основные</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="71"/>
        <source>Media settings</source>
        <translation>Настройки мультимедиа</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1029"/>
        <source>Preferred audio and subtitles</source>
        <translation>Предпочитаемые звуковая дорожка и субтитры</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="876"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="932"/>
        <source>Start videos in fullscreen</source>
        <translation>Открывать видео на весь экран</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="952"/>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation>Если эта опция отмечена, ROSA Media Player попытается предотвратить появление хранителя экрана во время воспроизведения видеофайла. Скринсейвер разрешён только при воспроизведении аудиофайлов или в режиме паузы. Эта опция работает только если окно ROSA Media Player активно.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="958"/>
        <source>Disable screensaver</source>
        <translation>Подавить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="965"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="120"/>
        <source>Select the mplayer executable</source>
        <translation>Выбрать исполняемый файл mplayer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="122"/>
        <source>Executables</source>
        <translation>Пути</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="124"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="126"/>
        <source>Select a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="833"/>
        <source>MPlayer executable</source>
        <translation>Исполняемый файл MPlayer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="834"/>
        <source>Here you must specify the mplayer executable that ROSA Media Player will use.&lt;br&gt;ROSA Media Player requires at least MPlayer 1.0rc1 (although a recent revision from SVN is highly recommended).</source>
        <translation>Здесь вы должны указать исполняемый файл mplayer, который будет использовать ROSA Media Player.&lt;br&gt;для ROSA Media Player необходим как минимум MPlayer 1.0rc1 (хотя рекомендуются последние ревизии из SVN).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="838"/>
        <source>If this setting is wrong, ROSA Media Player won&apos;t be able to play anything!</source>
        <translation>Если эта опция указана неправильно, ROSA Media Player не сможет ничего воспроизвести!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="842"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation>По умолчанию ROSA Media Player запоминает настройки каждого воспроизводимого файла (звуковая дорожка, громкость, фильтры...). Отключите эту опцию, если она вам не нравится.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="847"/>
        <source>If you check this option, ROSA Media Player will remember the last position of the file when you open it again. This option works only with regular files (not with DVDs, CDs, URLs...).</source>
        <translation>Если вы отметите эту опцию, ROSA Media Player будет запоминать последнюю позицию файла, когда вы снова его откроете. Эта опция работаеттолько с обычными файлами (не с DVD, CD или сетевыми адресами...).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="855"/>
        <source>Screenshots folder</source>
        <translation>Каталог снимков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="856"/>
        <source>Here you can specify a folder where the screenshots taken by ROSA Media Player will be stored. If the folder is not valid the screenshot feature will be disabled.</source>
        <translation>Здесь можно указать каталог, куда будут сохраняться скнимки экрана, сделанные ROSA Media Player-ом. Если каталог не указан, возможность получения скриншотов будет отключена.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="869"/>
        <source>Automatically add files to playlist</source>
        <translation>Автоматически добавлять файлы в список</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="878"/>
        <source>Video output driver</source>
        <translation>Устройство вывода видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="967"/>
        <source>Audio output driver</source>
        <translation>Устройство вывода аудио</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="968"/>
        <source>Select the audio output driver.</source>
        <translation>Выберите устройство вывода для аудио.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="841"/>
        <source>Remember settings</source>
        <translation>Запомнить настройки</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="910"/>
        <source>Software video equalizer</source>
        <translation>Программный видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="911"/>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Вы можете попробовать эту опцию, если видеоэквалайзер не поддерживается вашей видео-картой, или выбранным драйвером вывода видео.&lt;br&gt;&lt;b&gt;Обратите внимание:&lt;/b&gt;эта опция несовместима с некоторыми драйверами вывода видео.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="933"/>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Если эта опция выбрана, всё видео будет стартовать в полноэкранном режиме.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1008"/>
        <source>Software volume control</source>
        <translation>Програмное управление громкостью</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1009"/>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Попробуйте эту опцию для использования программного микшера вместо аппаратного.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="896"/>
        <source>Postprocessing quality</source>
        <translation>Качество постобработки</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="897"/>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Динамическое изменение степени постпроцессинга в зависимости от количества свободного процессорного времени. Указанное вами число будет соответствовать максимальному уровню.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="77"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>За&amp;поминать настройки всех файлов (звук, субтитры...)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="194"/>
        <source>Playlist</source>
        <translation>Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="200"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation>&amp;Автоматически добавлять файлы в список</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="324"/>
        <source>&amp;Quality:</source>
        <translation>Ка&amp;чество:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="489"/>
        <source>Start videos in &amp;fullscreen</source>
        <translation>Запускать видео на весь экр&amp;ан</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="503"/>
        <source>Disable &amp;screensaver</source>
        <translation>Отключить &amp;хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="729"/>
        <source>Use s&amp;oftware volume control</source>
        <translation>Програ&amp;ммное управление громкостью</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="752"/>
        <source>Ma&amp;x. Amplification:</source>
        <translation>Ма&amp;кс. увеличение:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="619"/>
        <source>&amp;AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS &amp;через S/PDIF</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="916"/>
        <source>Direct rendering</source>
        <translation>Прямой рендеринг</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="921"/>
        <source>Double buffering</source>
        <translation>Двойная буферизация</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="455"/>
        <source>D&amp;irect rendering</source>
        <translation>Прямой рен&amp;деринг</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="462"/>
        <source>Dou&amp;ble buffering</source>
        <translation>Двойная &amp;буферизация</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="922"/>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation>Двойная буферизация исправляет мерцание кадров благодаря тому, что в память загружается два кадра и, при отображении одного, обрабатывается следующий. Выключение этого параметра может негативно сказаться на OSD.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="304"/>
        <source>&amp;Enable postprocessing by default</source>
        <translation>Разрешить &amp;постобработку по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="780"/>
        <source>Volume &amp;normalization by default</source>
        <translation>&amp;Нормализация громкости по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="860"/>
        <source>Close when finished</source>
        <translation>Закрыть по окончании воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="861"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Если выбрано, то главное окно будет автоматически закрыто по окончании воспроизведения файла или списка.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="98"/>
        <source>2 (Stereo)</source>
        <translation>2 (Стерео)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="99"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="100"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="634"/>
        <source>C&amp;hannels by default:</source>
        <translation>Каналы по &amp;умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="181"/>
        <source>&amp;Pause when minimized</source>
        <translation>Пауза при &amp;минимизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="864"/>
        <source>Pause when minimized</source>
        <translation>Пауза при минимизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="893"/>
        <source>Enable postprocessing by default</source>
        <translation>Включить постобработку по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1012"/>
        <source>Max. Amplification</source>
        <translation>Макс. усиление</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="982"/>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS через S/PDIF</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1019"/>
        <source>Volume normalization by default</source>
        <translation>Нормализация громкости по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1020"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation>Увеличивает громкость без искажений звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="987"/>
        <source>Channels by default</source>
        <translation>Каналы по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1013"/>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation>Устанавливает максимальное усиление в процентах (по умолчанию 110). Значение 200 увеличит громкость до уровня, превышающего текущий вдвое. При значениях ниже 100 начальная грокость (100%) будет выше максимума, т.е. OSD будет показывать некорректную информацию.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="894"/>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation>Постобработка будет использована для новых открытых файлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="670"/>
        <source>High speed &amp;playback without altering pitch</source>
        <translation>Высоко&amp;скоростное воспроизведение без питч-эффекта</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="998"/>
        <source>High speed playback without altering pitch</source>
        <translation>Высокоскоростное воспроизведение без питч-эффекта</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="999"/>
        <source>Allows to change the playback speed without altering pitch. Requires at least MPlayer dev-SVN-r24924.</source>
        <translation>Позволяет изменить скорость воспроизведения без питч-эффекта. Требует как минимум версию MPlayer dev-SVN-r24924.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="224"/>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="448"/>
        <source>Use s&amp;oftware video equalizer</source>
        <translation>Использовать программный видео&amp;эквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="547"/>
        <source>A&amp;udio</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="705"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="104"/>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="105"/>
        <source>Lowpass5</source>
        <translation>Lowpass5</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="106"/>
        <source>Yadif (normal)</source>
        <translation>Yadif (обычный)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="107"/>
        <source>Yadif (double framerate)</source>
        <translation>Yadif (2× частота кадров)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="108"/>
        <source>Linear Blend</source>
        <translation>Линейное смешивание</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="109"/>
        <source>Kerndeint</source>
        <translation>Адаптивное (mplayer)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="901"/>
        <source>Deinterlace by default</source>
        <translation>Удаление &quot;гребёнки&quot; по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="902"/>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation>Выберите фильтр деинтерлейсинга (удаление &quot;гребёнки&quot;), который вы хотите использовать по умолчанию для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="846"/>
        <source>Remember time position</source>
        <translation>Помнить позицию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="111"/>
        <source>Remember &amp;time position</source>
        <translation>Помнить п&amp;озицию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="979"/>
        <source>Enable the audio equalizer</source>
        <translation>Включить аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="980"/>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation>Отметьте эту опцию, если хотите использовать аудиоэквалайзер.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="612"/>
        <source>&amp;Enable the audio equalizer</source>
        <translation>Включить &amp;аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="926"/>
        <source>Draw video using slices</source>
        <translation>Отрисовывать видео с использованием слоёв</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="927"/>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation>Включает/отключает отрисовку видео слоями/полосами по 16-пикселов высотой, вместо отрисовки целого кадра за один проход. Может быть быстрее или медленнее, в зависимости от видео карты и доступного кеша. Полезно только с кодеками libmpeg2 и libavcodec.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="469"/>
        <source>Dra&amp;w video using slices</source>
        <translation>Отри&amp;совывать видео с использованием слоёв</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="174"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Закрыть по окончании воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="294"/>
        <location filename="../prefgeneral.cpp" line="320"/>
        <source>fast</source>
        <translation>быстро</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="295"/>
        <location filename="../prefgeneral.cpp" line="316"/>
        <source>slow</source>
        <translation>медленно</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="321"/>
        <source>fast - ATI cards</source>
        <translation>быстро – видеокарты ATI</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="337"/>
        <location filename="../prefgeneral.cpp" line="365"/>
        <source>User defined...</source>
        <translation>Определено пользователем...</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="870"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation>Если эта опция отмечена, каждый раз при открытии файла, ROSA Media Player будет первым делом очищать список и затем добавлять файл в него. Касательно DVD, CD и VCD, все заголовки на диске будут добавлены в плейлист.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="906"/>
        <source>Default zoom</source>
        <translation>Увеличение по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="907"/>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation>Эта опция устанавливает увеличение по умолчанию для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="394"/>
        <source>Default &amp;zoom:</source>
        <translation>У&amp;величение по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="879"/>
        <source>Select the video output driver. %1 provides the best performance.</source>
        <translation>Выберите устройство вывода изображения на экран. %1 обеспечивает максимальную производительность.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="971"/>
        <source>%1 is the recommended one. Try to avoid %2 and %3, they are slow and can have an impact on performance.</source>
        <translation>Рекомендуется %1. Постарайтесь исключить %2 и %3, они медленные и могут ухудшить производительность.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="865"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>При включении этой опции, файл будет поставлен на паузу при минимизации главного окна. После восстановления окна воспроизведение продолжится.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="959"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Отметьте эту опцию, чтобы отключить хранитель экрана во время воспроизведения.&lt;br&gt; Он будет включен снова по окончании воспроизведения.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="232"/>
        <location filename="../prefgeneral.ui" line="555"/>
        <source>Ou&amp;tput driver:</source>
        <translation>Устройство &amp;вывода:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="936"/>
        <source>Add black borders on fullscreen</source>
        <translation>Добавить чёрные полосы в полноэкранном режиме</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="937"/>
        <source>If this option is enabled, black borders will be added to the image in fullscreen mode. This allows subtitles to be displayed on the black borders.</source>
        <translation>Если эта опция включена, в полноэкранном режиме к изображению будут добавлены чёрные полосы. Это позволяет отображать на них субтитры.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="496"/>
        <source>&amp;Add black borders on fullscreen</source>
        <translation>Добавить &amp;чёрные полосы в полноэкранном режиме</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="917"/>
        <source>If checked, turns on direct rendering (not supported by all codecs and video outputs)&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; May cause OSD/SUB corruption!</source>
        <translation>Если выбрано – включается прямой рендеринг (поддерживается не всеми кодеками и модулями видео вывода)&lt;br&gt;&lt;b&gt;ВНИМАНИЕ:&lt;/b&gt; Могут возникнуть проблемы с OSD/субтитрами!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="988"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Запрашивает количество каналов воспроизведения. MPlayer просит декодер декодировать звук в указанное количество каналов. Выполнение задачи ложится на плечи декодера. Обычно это требуется только при воспроизведении видео с AC3 звуком (например DVD). В этом случае liba52 выполняет декодирование как обычно и корректно сводит аудио в запрошенное количество каналов. &lt;b&gt;ПРИМЕЧАНИЕ&lt;/b&gt;: Эта опция учитывается кодеками (AC3), фильтрами (окружение) и драверами вывода звука (как минимум OSS).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="851"/>
        <source>Enable screenshots</source>
        <translation>Включить снимки экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="852"/>
        <source>You can use this option to enable or disable the possibility to take screenshots.</source>
        <translation>Вы можете использовать эту опцию для того, чтобы задействовать или отключить возможность делать снимки экрана.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="47"/>
        <source>&amp;MPlayer executable:</source>
        <translation>Пут&amp;ь к mplayer:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="129"/>
        <source>Screenshots</source>
        <translation>Снимки экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="135"/>
        <source>&amp;Enable screenshots</source>
        <translation>&amp;Включить снимки экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="151"/>
        <source>&amp;Folder:</source>
        <translation>&amp;Каталог:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1002"/>
        <source>Global volume</source>
        <translation>Общая громкость</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1003"/>
        <source>If this option is checked, the same volume will be used for all files you play. If the option is not checked each file uses its own volume.</source>
        <translation>При включении этой опции будет использоваться общая громкость для всех файлов. Если опция отключена, для каждого файла будет использована своя громкость.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1006"/>
        <source>This option also applies for the mute control.</source>
        <translation>Эта опция также применяется для приглушением (mute) звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="714"/>
        <source>Glo&amp;bal volume</source>
        <translation>О&amp;бщая громкость</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="945"/>
        <source>Switch screensaver off</source>
        <translation>Отключить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="946"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation>Эта опция отключает хранитель экрана перед началом воспроизведения файла и включает его по окончании воспроизведения. Если эта опция задействована, скринсевер не будет появляться даже при воспроизведении аудиофайлов или когда воспроизведение присостановлено.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="951"/>
        <source>Avoid screensaver</source>
        <translation>Предотвратить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="510"/>
        <source>Screensaver</source>
        <translation>Хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="516"/>
        <source>Swit&amp;ch screensaver off</source>
        <translation>&amp;Отключить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="523"/>
        <source>Avoid &amp;screensaver</source>
        <translation>Пре&amp;дотвратить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1022"/>
        <source>Audio/video auto synchronization</source>
        <translation>Автосинхронизация звука/видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1023"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Плавно подстраивает A/V-синхронизацию за счёт измерений задержки аудио.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1026"/>
        <source>A-V sync correction</source>
        <translation>Коррекция A/V-синхронизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1027"/>
        <source>Maximum A-V sync correction per frame (in seconds)</source>
        <translation>Максимальная коррекция A/V-синхронизации на фрейм (в секундах)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="790"/>
        <source>Synchronization</source>
        <translation>Синхронизация</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="801"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Автоматическая син&amp;хронизация аудио/видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="827"/>
        <source>&amp;Factor:</source>
        <translation>&amp;Фактор:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="863"/>
        <source>A-V sync &amp;correction</source>
        <translation>Ко&amp;ррекция A/V-синхронизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="886"/>
        <source>&amp;Max. correction:</source>
        <translation>Макс. коррек&amp;ция:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="904"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; This option won&apos;t be used for TV channels.</source>
        <translation>&lt;b&gt;Внимание:&lt;/b&gt; Эта опция не будет использоваться для ТВ-каналов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="357"/>
        <source>Dei&amp;nterlace by default (except for TV):</source>
        <translation>&amp;Удаление &quot;гребёнки&quot; по умолчанию (кроме ТВ):</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="888"/>
        <source>Disable video filters when using vdpau</source>
        <translation>Отключить видеофильтры при использовании vdpau</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="889"/>
        <source>Usually video filters won&apos;t work when using vdpau as video output driver, so it&apos;s wise to keep this option checked.</source>
        <translation>Обычно видеофильтры не работают при использовании vdpau в качестве устройства вывода, таким образом, эта настройка будет неплохим выбором.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="276"/>
        <source>Disable video filters when using vd&amp;pau</source>
        <translation>Отключить видеофильтры при использовании vdpau</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="983"/>
        <source>Uses hardware AC3 passthrough.</source>
        <translation>Использовать AC3 через S/PDIF.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="984"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; none of the audio filters will be used when this option is enabled.</source>
        <translation>&lt;b&gt;Примечание:&lt;/b&gt; ни один из аудиофильтров не будет задействован при включении этой опции.</translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <location filename="../prefinput.cpp" line="40"/>
        <source>Keyboard and mouse</source>
        <translation>Устройства ввода</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="24"/>
        <source>&amp;Keyboard</source>
        <translation>&amp;Клавиатура</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="44"/>
        <location filename="../prefinput.ui" line="297"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="157"/>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Здесь можно изменить настройки горячих клавиш. Чтобы сделать это, дважды кликните мышкой или нажмите клавишу в необходимой ячейке. Вы можете сохранить список горячих клавиш, чтобы им могли воспользоваться другие люди или вы сами на другом компьютере.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="86"/>
        <source>&amp;Mouse</source>
        <translation>&amp;Мышь</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="98"/>
        <source>Button functions:</source>
        <translation>Функции кнопки:</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="149"/>
        <source>Media seeking</source>
        <translation>Прокрутка</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="150"/>
        <source>Volume control</source>
        <translation>Регулятор громкости</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="151"/>
        <source>Zoom video</source>
        <translation>Увеличение</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="57"/>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="60"/>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Здесь можно изменить настройки горячих клавиш. Чтобы сделать это, дважды щёлкните мышкой или нажмите клавишу в необходимой ячейке. Вы можете сохранить список горячих клавиш, чтобы им могли воспользоваться другие люди или вы сами на другом компьютере.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="276"/>
        <source>&amp;Left click</source>
        <translation>&amp;Левый клик</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="134"/>
        <source>&amp;Double click</source>
        <translation>&amp;Двойной щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="333"/>
        <source>&amp;Wheel function:</source>
        <translation>&amp;Функция колеса:</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="298"/>
        <source>Shortcut editor</source>
        <translation>Редактор сочетаний клавиш</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="299"/>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation>Эта таблица позволяет изменить сочетания клавиш для различных действий. Двойной клик или нажатие ввода на выбранном пункте или нажатие кнопки &lt;b&gt;Изменить&lt;/b&gt; вызовет диалог &lt;i&gt;Изменить горячую клавишу&lt;/i&gt;. Есть два способа изменить сочетание клавиш: если кнопка &lt;b&gt;Захват&lt;/b&gt; нажата - просто нажать нужную комбинацию клавиш (работает не для всех клавиш). Если кнопка &lt;b&gt;Захват&lt;/b&gt; отжата, можно просто вписать полное название комбинации клавиш.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="311"/>
        <source>Left click</source>
        <translation>Левый клик</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="312"/>
        <source>Select the action for left click on the mouse.</source>
        <translation>Выбрать действие для левого клика мыши.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="314"/>
        <source>Double click</source>
        <translation>Двойной клик</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="315"/>
        <source>Select the action for double click on the mouse.</source>
        <translation>Выбрать действие для двойного клика мыши.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="326"/>
        <source>Wheel function</source>
        <translation>Функция колеса</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="327"/>
        <source>Select the action for the mouse wheel.</source>
        <translation>Выбрать действие для функции колеса.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="58"/>
        <source>Play</source>
        <translation>Воспроизведение</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="60"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="62"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="71"/>
        <source>Fullscreen</source>
        <translation>Полный экран</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="72"/>
        <source>Compact</source>
        <translation>Компактно</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="73"/>
        <source>Screenshot</source>
        <translation>Снимок экрана</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="77"/>
        <source>Mute</source>
        <translation>Приглушение</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="83"/>
        <source>Frame counter</source>
        <translation>Счётчик кадров</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="80"/>
        <source>Reset zoom</source>
        <translation>Сбросить увеличение</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="81"/>
        <source>Exit fullscreen</source>
        <translation>Выйти из поноэкранного режима</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="85"/>
        <source>Double size</source>
        <translation>Двойной размер</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="59"/>
        <source>Play / Pause</source>
        <translation>Воспроизведение / Пауза</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="61"/>
        <source>Pause / Frame step</source>
        <translation>Пауза / Покадровый просмотр</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="79"/>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="84"/>
        <source>Preferences</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="148"/>
        <source>No function</source>
        <translation>Нет функции</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="152"/>
        <source>Change speed</source>
        <translation>Изменить скорость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="82"/>
        <source>Normal speed</source>
        <translation>Нормальная скорость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="296"/>
        <source>Keyboard</source>
        <translation>Клавиатура</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="309"/>
        <source>Mouse</source>
        <translation>Мышь</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="317"/>
        <source>Middle click</source>
        <translation>Средний клик</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="318"/>
        <source>Select the action for middle click on the mouse.</source>
        <translation>Выбрать действие для среднего клика мыши.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="179"/>
        <source>M&amp;iddle click</source>
        <translation>С&amp;редний клик</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="205"/>
        <source>X Button &amp;1</source>
        <translation>Доп. кнопка &amp;1</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="231"/>
        <source>X Button &amp;2</source>
        <translation>Доп. кнопка &amp;2</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="63"/>
        <source>Go backward (short)</source>
        <translation>Назад (малый интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="64"/>
        <source>Go backward (medium)</source>
        <translation>Назад (средний интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="65"/>
        <source>Go backward (long)</source>
        <translation>Назад (длинный интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="66"/>
        <source>Go forward (short)</source>
        <translation>Вперёд (короткий интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="67"/>
        <source>Go forward (medium)</source>
        <translation>Вперёд (средний интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="68"/>
        <source>Go forward (long)</source>
        <translation>Вперёд (длинный интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="78"/>
        <source>OSD - Next level</source>
        <translation>OSD – Следующий уровень</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="88"/>
        <source>Show context menu</source>
        <translation>Показать контестное меню</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="391"/>
        <source>&amp;Right click</source>
        <translation>&amp;Правый клик</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="69"/>
        <source>Increase volume</source>
        <translation>Увеличить громкость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="70"/>
        <source>Decrease volume</source>
        <translation>Уменьшить громкость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="320"/>
        <source>X Button 1</source>
        <translation>Доп. кнопка 1</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="321"/>
        <source>Select the action for the X button 1.</source>
        <translation>Выбрать действие для доп. кнопки 1.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="323"/>
        <source>X Button 2</source>
        <translation>Доп. кнопка 2</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="324"/>
        <source>Select the action for the X button 2.</source>
        <translation>Выбрать действие для доп. кнопки 1.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="86"/>
        <source>Show video equalizer</source>
        <translation>Показать видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="87"/>
        <source>Show audio equalizer</source>
        <translation>Показать аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="74"/>
        <source>Always on top</source>
        <translation>Всегда наверху</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="75"/>
        <source>Never on top</source>
        <translation>Никогда наверху</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="76"/>
        <source>On top while playing</source>
        <translation>Наверху во время воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="91"/>
        <source>Activate option under mouse in DVD menus</source>
        <translation>Активировать опцию под мышью в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="92"/>
        <source>Return to main DVD menu</source>
        <translation>Вернуться к главному DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="93"/>
        <source>Return to previous menu in DVD menus</source>
        <translation>Вернуться к предыдущему DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="94"/>
        <source>Move cursor up in DVD menus</source>
        <translation>Передвинуть курсор вверх в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="95"/>
        <source>Move cursor down in DVD menus</source>
        <translation>Передвинуть курсор вниз в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="96"/>
        <source>Move cursor left in DVD menus</source>
        <translation>Передвинуть курсор влево в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="97"/>
        <source>Move cursor right in DVD menus</source>
        <translation>Передвинуть курсор вправо в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="98"/>
        <source>Activate highlighted option in DVD menus</source>
        <translation>Активировать подсвеченный пункт в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="89"/>
        <source>Change function of wheel</source>
        <translation>Изменить функцию колеса мыши</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="329"/>
        <source>Reverse mouse wheel seeking</source>
        <translation>Инвертировать направление перемотки</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="330"/>
        <source>Check it to seek in the opposite direction.</source>
        <translation>Выберите это для противоположного направления.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="372"/>
        <source>R&amp;everse wheel media seeking</source>
        <translation>Инв&amp;ертировать направление перемотки</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <location filename="../prefinterface.cpp" line="76"/>
        <location filename="../prefinterface.cpp" line="418"/>
        <source>Interface</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="93"/>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Автоопределение&gt;</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="126"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="27"/>
        <source>&amp;Interface</source>
        <translation>&amp;Интерфейс</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="126"/>
        <location filename="../prefinterface.cpp" line="428"/>
        <source>Recent files</source>
        <translation>Последние файлы</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="83"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="88"/>
        <source>Whenever it&apos;s needed</source>
        <translation>Когда это нужно</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="93"/>
        <source>Only after loading a new video</source>
        <translation>Только для нового видео</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="433"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="434"/>
        <source>Here you can change the language of the application.</source>
        <translation>Здесь можно изменить язык приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="442"/>
        <source>Instances</source>
        <translation>Экземпляры</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="138"/>
        <source>Ma&amp;x. items</source>
        <translation>&amp;Количество пунктов в меню</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="244"/>
        <source>St&amp;yle:</source>
        <translation>&amp;Стиль:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="198"/>
        <source>L&amp;anguage:</source>
        <translation>&amp;Язык:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="39"/>
        <source>Main window</source>
        <translation>Главное окно</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="66"/>
        <source>Auto&amp;resize:</source>
        <translation>Автоматически изменять &amp;размер:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="101"/>
        <source>R&amp;emember position and size</source>
        <translation>Запоминать пози&amp;цию и размер</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="293"/>
        <source>Default font:</source>
        <translation>Шрифт по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="307"/>
        <source>&amp;Change...</source>
        <translation>&amp;Изменить...</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="51"/>
        <location filename="../prefinterface.ui" line="350"/>
        <source>TextLabel</source>
        <translation>Текстовая метка</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="330"/>
        <source>Ins&amp;tances</source>
        <translation>&amp;Экземпляры</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="420"/>
        <source>Autoresize</source>
        <translation>Автоматический размер</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="421"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation>Главное окно может изменять размер автоматически. Выберите предпочтительную настройку.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="424"/>
        <source>Remember position and size</source>
        <translation>Запоминать позицию и размер</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="429"/>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation>Выберите максимальное количество элементов в подменю &lt;b&gt;Открыть-&gt;Последние файлы&lt;/b&gt;. При значении 0 меню не будет показано вообще.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="436"/>
        <source>Style</source>
        <translation>Стиль</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="437"/>
        <source>Select the style you prefer for the application.</source>
        <translation>Выберите предпочитаемый стиль приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="439"/>
        <source>Default font</source>
        <translation>Шрифт по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="440"/>
        <source>You can change here the application&apos;s font.</source>
        <translation>Здесь можно изменить шрифт приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="209"/>
        <source>Default GUI</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="449"/>
        <source>Automatic port</source>
        <translation>Порт автоматически</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="454"/>
        <source>Manual port</source>
        <translation>Указание порта вручную</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="375"/>
        <source>Port to listen</source>
        <translation>Порт для прослушивания</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="387"/>
        <source>&amp;Automatic</source>
        <translation>&amp;Автоматически</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="402"/>
        <source>&amp;Manual</source>
        <translation>&amp;Вручную</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="425"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation>Если настройка выбрана, позиция и размер видео будут сохранены и восстановлены при следующем запуске ROSA Media Player.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="445"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation>Использовать только одну копию ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="446"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation>Выберите эту опцию, если хотите использовать уже запущенную копию ROSA Media Player при открытии новых файлов.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="450"/>
        <source>ROSA Media Player needs to listen to a port to receive commands from other instances. If you select this option, a port will be automatically chosen.</source>
        <translation>ROSA Media Player требует прослушивания порта для получения команд от других экземпляров. Если вы отметите эту опцию, порт будет выбран автоматически.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="455"/>
        <source>ROSA Media Player needs to listen to a port to receive commands from other instances. You can change the port in case the default one is used by another application.</source>
        <translation>ROSA Media Player требует прослушивания порта для получения команд от других экземпляров. Если значение по умолчанию используется другим приложением, вы можете изменить его.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="461"/>
        <source>Floating control</source>
        <translation>Плавающая панель</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="463"/>
        <source>Animated</source>
        <translation>Анимировать</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="464"/>
        <source>If this option is enabled, the floating control will appear with an animation.</source>
        <translation>Если эта опция отмечена, плавающая панель управления будет появляться с анимацией.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="467"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="468"/>
        <source>Specifies the width of the control (as a percentage).</source>
        <translation>Определяет ширину панели (в процентах).</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="470"/>
        <source>Margin</source>
        <translation>Отступ</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="471"/>
        <source>This option sets the number of pixels that the floating control will be away from the bottom of the screen. Useful when the screen is a TV, as the overscan might prevent the control to be visible.</source>
        <translation>Эта опция устанавливает количество пикселов, на которое плавающая панель будет отступать от низа экрана. Полезно когда экраном является телевизор, и картинка увеличена, таким образом предотвращается случай, когда плавающая панель будет невидима.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="483"/>
        <source>Bypass window manager</source>
        <translation>Обход менеджера окон</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="484"/>
        <source>If this option is checked, the control is displayed bypassing the window manager. Disable this option if the floating control doesn&apos;t work well with your window manager.</source>
        <translation>Если эта опция отмечена, панель управления будет отображаться в обход менеджера окон. Отключите эту опцию, если панель управления работает некорректно с вашим оконным менеджером.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="365"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation>Запускать только о&amp;дну копию ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="458"/>
        <source>&amp;Floating control</source>
        <translation>П&amp;лавающая панель</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="464"/>
        <source>The floating control appears in fullscreen mode when the mouse is moved to the bottom of the screen.</source>
        <translation>Плавающая панель управления появляется в полноэкранном режиме, когда указатель мыши перемещается в нижнюю часть экрана.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="474"/>
        <source>&amp;Animated</source>
        <translation>&amp;Анимировать</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="483"/>
        <source>&amp;Width:</source>
        <translation>&amp;Ширина:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="509"/>
        <location filename="../prefinterface.ui" line="542"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="516"/>
        <source>&amp;Margin:</source>
        <translation>&amp;Отступ:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="551"/>
        <source>&amp;Bypass window manager</source>
        <translation>&amp;Обход менеджера окон</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <location filename="../prefperformance.cpp" line="51"/>
        <location filename="../prefperformance.cpp" line="268"/>
        <source>Performance</source>
        <translation>Быстродействие</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="35"/>
        <source>&amp;Performance</source>
        <translation>&amp;Быстродействие</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="56"/>
        <location filename="../prefperformance.cpp" line="272"/>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="77"/>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Укажите приоритет процесса для MPlayer.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="118"/>
        <source>realtime</source>
        <translation>реальное время</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="123"/>
        <source>high</source>
        <translation>высокий</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="128"/>
        <source>abovenormal</source>
        <translation>выше обычного</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="133"/>
        <source>normal</source>
        <translation>обычный</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="138"/>
        <source>belownormal</source>
        <translation>ниже обычного</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="143"/>
        <source>idle</source>
        <translation>низкий</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="323"/>
        <source>Cache</source>
        <translation>Кэш</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="401"/>
        <location filename="../prefperformance.ui" line="438"/>
        <location filename="../prefperformance.ui" line="475"/>
        <location filename="../prefperformance.ui" line="512"/>
        <location filename="../prefperformance.ui" line="549"/>
        <location filename="../prefperformance.ui" line="586"/>
        <source>KB</source>
        <translation>Кб</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="374"/>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Установки кэша могут улучшить или ухудшить быстродействие</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="278"/>
        <source>Allow frame drop</source>
        <translation>Допускать выпадение кадров</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="279"/>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Пропускать кадры для поддержки аудио/видео синхронизации.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="281"/>
        <source>Allow hard frame drop</source>
        <translation>Допускать жесткое выпадение кадров</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="282"/>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Более жесткое пропускание кадров (рваное воспроизведение). Приводит к искажению картинки!</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="104"/>
        <source>Priorit&amp;y:</source>
        <translation>П&amp;риоритет:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="172"/>
        <source>&amp;Allow frame drop</source>
        <translation>&amp;Допускать выпадение кадров</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="179"/>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation>Допускать &amp;жесткое выпадение кадров (изображение может исказиться)</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="319"/>
        <source>&amp;Fast audio track switching</source>
        <translation>&amp;Быстрое переключение звуковых дорожек</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="347"/>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation>Быстрый &amp;поиск по главам на DVD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="308"/>
        <source>Fast audio track switching</source>
        <translation>Быстрое переключение звуковых дорожек</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="318"/>
        <source>Fast seek to chapters in dvds</source>
        <translation>Быстрый поиск по главам на DVD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="319"/>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation>Если отмечено, SMPlayer попытается использовать более быстрый метод для поиска по главам, но эта опция может не работать с некоторыми дисками.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="292"/>
        <source>Skip loop filter</source>
        <translation>Пропустить петелевой фильтр</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="241"/>
        <source>H.264</source>
        <translation>H.264</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="325"/>
        <source>Cache for files</source>
        <translation>Кэширование файлов</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="326"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation>Эта опция определяет количество памяти (в кБайтах), используетмых для предварительного кэширования файлов.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="329"/>
        <source>Cache for streams</source>
        <translation>Кэширование потоков</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="330"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation>Эта опция определяет количество памяти (в кБайтах), используетмых для предварительного кэширования URL.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="333"/>
        <source>Cache for DVDs</source>
        <translation>Кэшировать DVD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="334"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation>Эта опция определяет количество памяти (в кБайтах), используетмых для предварительного кэширования DVD.&lt;br&gt;&lt;b&gt;Внимание:&lt;/b&gt; Перемотка может работать неправильно (в том числе и обзор глав) при использовании кэширования DVD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="368"/>
        <source>&amp;Cache</source>
        <translation>&amp;Кэш</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="458"/>
        <source>Cache for &amp;DVDs:</source>
        <translation>&amp;Кэш DVD:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="384"/>
        <source>Cache for &amp;local files:</source>
        <translation>Кэш локальных &amp;файлов:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="421"/>
        <source>Cache for &amp;streams:</source>
        <translation>Кэш &amp;потоков:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="68"/>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="69"/>
        <source>Skip (always)</source>
        <translation>Пропускать (всегда)</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="70"/>
        <source>Skip only on HD videos</source>
        <translation>Пропускать только для HD видео</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="293"/>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation>Эта опция позволяет пропускать петелевой фильр (он же debloking) во время декодирования H.264. Поскольку фильтрованный кадр предполагается использовать в качестве ссылки для декодирования зависимых кадров, то качество, например, у MPEG-2, будет хуже, чем если бы deblocking не производился вообще. Но, как минимум, для HDTV с высоким битрейтом это даёт значительный прирост производительности без видимой потери качества.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="300"/>
        <source>Possible values:</source>
        <translation>Возможные значения:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="301"/>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation>&lt;b&gt;Включено&lt;/b&gt;: петелевой фильтр не пропускается</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="302"/>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation>&lt;b&gt;Пропускать (всегда)&lt;/b&gt;: петелевой фильтр не применяется вне зависимости от разрешения видео</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="304"/>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation>&lt;b&gt;Включено&lt;/b&gt;: петелевой фильтр пропускается только для видео с высотой картинки %1 или выше.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="309"/>
        <source>Possible values:&lt;br&gt; &lt;b&gt;Yes&lt;/b&gt;: it will try the fastest method to switch the audio track (it might not work with some formats).&lt;br&gt; &lt;b&gt;No&lt;/b&gt;: the MPlayer process will be restarted whenever you change the audio track.&lt;br&gt; &lt;b&gt;Auto&lt;/b&gt;: ROSA Media Player will decide what to do according to the MPlayer version.</source>
        <translation>Возможные значения: &lt;br&gt; &lt;b&gt;Да&lt;/b&gt;: будет использован наиболее быстрый метод переключения аудио дорожек (может не работать с некоторыми форматами).&lt;br&gt; &lt;b&gt;Нет&lt;/b&gt;: процесс MPlayer будет перезапущен при изменении звуковой дорожки.&lt;br&gt; &lt;b&gt;Авто&lt;/b&gt;: ROSA Media Player решит самостоятельно, основываясь на версии MPlayer.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="264"/>
        <source>Loop &amp;filter</source>
        <translation>Петелевой &amp;фильтр</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="338"/>
        <source>Cache for audio CDs</source>
        <translation>Кэшировть аудио CD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="339"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation>Эта опция определяет количество памяти (в кБайтах), используетмых для предварительного кэширования аудио CD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="495"/>
        <source>Cache for &amp;audio CDs:</source>
        <translation>Кэш &amp;аудио CD:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="342"/>
        <source>Cache for VCDs</source>
        <translation>Кэшировать видео CD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="343"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation>Эта опция определяет количество памяти (в кБайтах), используетмых для предварительного кэширования видео CD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="532"/>
        <source>Cache for &amp;VCDs:</source>
        <translation>Кэш &amp;видео CD:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="285"/>
        <source>Threads for decoding</source>
        <translation>Потоки декодирования</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="286"/>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation>Установите количество потоков для декодирования. Только для MPEG-1/2 и H.264</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="203"/>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation>&amp;Потоков декодирования (только для MPEG-1/2 и H.264):</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="273"/>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Устанавливает приоритет процесса mplayer согласно предопределённым приоритам, доступным для Windows.&lt;br&gt;&lt;b&gt;Внимание:&lt;/b&gt; Использование приоритета реального времени может сильно замедлить работу системы.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="289"/>
        <source>Use CoreAVC if no other codec specified</source>
        <translation>Использовать CoreAVC, если другой кодек не указан</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="290"/>
        <source>Try to use non-free CoreAVC codec with no other codec is specified and non-VDPAU video output selected. Requires MPlayer build with CoreAVC support.</source>
        <translation>Попытаться использовать несвободный кодек CoreAVC, если не указан другой кодек и выбран не-VDPAU видеодрайвер выхода. Требуется MPlayer, собранный с поддержкой CoreAVC.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="292"/>
        <source>&amp;Use CoreAVC if no other codec specified</source>
        <translation>И&amp;спользовать CoreAVC, если другой кодек не указан</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="569"/>
        <source>Cache for &amp;TV:</source>
        <translation>Кэш для &amp;ТВ:</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="53"/>
        <location filename="../prefsubtitles.cpp" line="462"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="101"/>
        <source>Choose a ttf file</source>
        <translation>Выбрать TTF файл</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="102"/>
        <source>Truetype Fonts</source>
        <translation>Шрифты Truetype</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="35"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="44"/>
        <location filename="../prefsubtitles.cpp" line="464"/>
        <source>Autoload</source>
        <translation>Автозагрузка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="89"/>
        <source>Same name as movie</source>
        <translation>С тем же именем, что и у фильма</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="94"/>
        <source>All subs containing movie name</source>
        <translation>Подключать субтитры содержащие название фильма</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="99"/>
        <source>All subs in directory</source>
        <translation>Все субтитры каталога</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="560"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="636"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="665"/>
        <source>Top</source>
        <translation>Верх</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="691"/>
        <source>Bottom</source>
        <translation>Низ</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="344"/>
        <location filename="../prefsubtitles.ui" line="804"/>
        <location filename="../prefsubtitles.cpp" line="499"/>
        <location filename="../prefsubtitles.cpp" line="557"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="388"/>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Выберите шрифт для субтитров (и OSD):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="428"/>
        <location filename="../prefsubtitles.cpp" line="560"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="483"/>
        <source>No autoscale</source>
        <translation>Без автомасштабирования</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="488"/>
        <source>Proportional to movie height</source>
        <translation>Пропорциональко высоте клипа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="493"/>
        <source>Proportional to movie width</source>
        <translation>Пропорционально ширине клипа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="498"/>
        <source>Proportional to movie diagonal</source>
        <translation>Пропорционально диагонали клипа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="537"/>
        <source>Subtitle position</source>
        <translation>Расположение субтитров</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="538"/>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Этот параметр определяет положение субтитров относительно окна. &lt;i&gt;100&lt;/i&gt; означает низ, &lt;i&gt;0&lt;/i&gt; – верх.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="68"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation>&amp;Автозагрузка субтитров (*.srt, *.sub...):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="81"/>
        <source>S&amp;elect first available subtitle</source>
        <translation>Загружать &amp;первые доступные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="149"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation>&amp;Кодировка субтитров по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="581"/>
        <source>Default &amp;position of the subtitles on screen</source>
        <translation>По&amp;ложение субтитров на экране по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="236"/>
        <source>&amp;Include subtitles on screenshots</source>
        <translation>&amp;Сохранять субтиры на снимках экрана</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="418"/>
        <source>&amp;TTF font:</source>
        <translation>TTF шри&amp;фт:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="398"/>
        <source>S&amp;ystem font:</source>
        <translation>&amp;Системный шрифт:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="469"/>
        <source>A&amp;utoscale:</source>
        <translation>А&amp;втомасштабирование:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="467"/>
        <source>Select first available subtitle</source>
        <translation>Выберите первые доступные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="473"/>
        <source>Default subtitle encoding</source>
        <translation>Кодировка субтитров по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="489"/>
        <source>Include subtitles on screenshots</source>
        <translation>Сохранять субтиры на снимках экрана</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="511"/>
        <source>TTF font</source>
        <translation>TTF шрифт</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="521"/>
        <source>System font</source>
        <translation>Системный шрифт</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="522"/>
        <source>Here you can select a system font to be used for the subtitles and OSD. &lt;b&gt;Note:&lt;/b&gt; requires a MPlayer with fontconfig support.</source>
        <translation>Зесь можно выбрать системный шрифт как шрифт по умолчанию для субтитров и OSD. &lt;b&gt;Заметка:&lt;/b&gt; требуется MPlayer с поддержкой fontconfig.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="525"/>
        <source>Autoscale</source>
        <translation>Автомасштабирование</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="569"/>
        <source>Text color</source>
        <translation>Цвет текста</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="570"/>
        <source>Select the color for the text of the subtitles.</source>
        <translation>Выберите цвет текста субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="572"/>
        <source>Border color</source>
        <translation>Цвет кромки</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="573"/>
        <source>Select the color for the border of the subtitles.</source>
        <translation>Выберите цвет кромки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="465"/>
        <source>Select the subtitle autoload method.</source>
        <translation>Выберите метод автозагрузки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="468"/>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation>Если доступно более одной дорожки субтитров, одна из них будет автоматически выбрана, обычно первая, хотя если одна из дорожек удовлетворяет выбранному пользоватлем предпочтительному языку, то будет выбрана именно она.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="526"/>
        <source>Select the subtitle autoscaling method.</source>
        <translation>Выберите метод автозагрузки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="474"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation>Выберите кодировку, которая будет использована для файлов субтитров по умолчанию.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="477"/>
        <source>Try to autodetect for this language</source>
        <translation>Автоматически определить для языка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="478"/>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a MPlayer compiled with ENCA support.</source>
        <translation>Если опция отмечена, будет произведена попытка автоматически определить кодировку для указанного языка. При ошибке будет использована кодировка по умолчанию. Опция требует MPlayer, скомпилированный с поддержкой ENCA.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="484"/>
        <source>Subtitle language</source>
        <translation>Язык субтитров</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="485"/>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation>Выберите язык, для которого будет производиться автоматическое определение кодировки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="126"/>
        <source>Encoding</source>
        <translation>Кодировка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="198"/>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation>А&amp;втоматически определить для языка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="512"/>
        <source>Here you can select a ttf font to be used for the subtitles. Usually you&apos;ll find a lot of ttf fonts in %1</source>
        <translation>Здесь можно выбрать ttf шрифт, используемый субтитрами. Обычно вы можете найти большое количество ttf шрифтов в %1</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="599"/>
        <source>Outline</source>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="558"/>
        <source>Select the font for the subtitles.</source>
        <translation>Выберите шрифт для субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="561"/>
        <source>The size in pixels.</source>
        <translation>Размер в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="563"/>
        <source>Bold</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="564"/>
        <source>If checked, the text will be displayed in &lt;b&gt;bold&lt;/b&gt;.</source>
        <translation>Если отмечено, текст будет отображаться &lt;b&gt;жирным&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="566"/>
        <source>Italic</source>
        <translation>Наклонный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="567"/>
        <source>If checked, the text will be displayed in &lt;i&gt;italic&lt;/i&gt;.</source>
        <translation>Если отмечено, текст будет отображаться &lt;b&gt;наклонным&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="578"/>
        <source>Left margin</source>
        <translation>Поле слева</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="579"/>
        <source>Specifies the left margin in pixels.</source>
        <translation>Определяет размер поля слева в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="581"/>
        <source>Right margin</source>
        <translation>Поле справа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="582"/>
        <source>Specifies the right margin in pixels.</source>
        <translation>Определяет размер поля справа в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="584"/>
        <source>Vertical margin</source>
        <translation>Вертикальное поле</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="585"/>
        <source>Specifies the vertical margin in pixels.</source>
        <translation>Определяет размер поля по вертикали в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="587"/>
        <source>Horizontal alignment</source>
        <translation>Выравнивание по горизонтали</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="588"/>
        <source>Specifies the horizontal alignment. Possible values are left, centered and right.</source>
        <translation>Определяет тип выравнивания по горизонтали. Возможные значения – слева, по центру и справа.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="591"/>
        <source>Vertical alignment</source>
        <translation>Выравнивание по вертикали</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="592"/>
        <source>Specifies the vertical alignment. Possible values: bottom, middle and top.</source>
        <translation>Определяет тип выравнивания по вертикали. Возможные значения – снизу, по середине и сверху.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="595"/>
        <source>Border style</source>
        <translation>Стиль границы</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="596"/>
        <source>Specifies the border style. Possible values: outline and opaque box.</source>
        <translation>Определяет стиль границы. Возможные значения: контур и непрозрачный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="603"/>
        <source>Shadow</source>
        <translation>Тень</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="831"/>
        <source>Si&amp;ze:</source>
        <translation>&amp;Размер:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="873"/>
        <source>Bol&amp;d</source>
        <translation>&amp;Жирный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="880"/>
        <source>&amp;Italic</source>
        <translation>&amp;Наклонный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="892"/>
        <source>Colors</source>
        <translation>Цвета</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="910"/>
        <source>&amp;Text:</source>
        <translation>&amp;Текст:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="936"/>
        <source>&amp;Border:</source>
        <translation>Грани&amp;ца:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="988"/>
        <source>Margins</source>
        <translation>Поля</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1006"/>
        <source>L&amp;eft:</source>
        <translation>С&amp;лева:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1022"/>
        <source>&amp;Right:</source>
        <translation>С&amp;права:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1038"/>
        <source>Verti&amp;cal:</source>
        <translation>По &amp;вертикали:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1070"/>
        <source>Alignment</source>
        <translation>Выравнивание:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1088"/>
        <source>&amp;Horizontal:</source>
        <translation>&amp;Горизонтальное</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1104"/>
        <source>&amp;Vertical:</source>
        <translation>Верти&amp;кальное:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1125"/>
        <source>Border st&amp;yle:</source>
        <translation>&amp;Стиль границы:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1151"/>
        <source>&amp;Outline:</source>
        <translation>К&amp;онтур:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1171"/>
        <source>Shado&amp;w:</source>
        <translation>Т&amp;ень:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="554"/>
        <source>The following options allows you to define the style to be used for non-styled subtitles (srt, sub...).</source>
        <translation>Следующие опции позволяют вам определить стиль, который будет использован для нестилизованных субтитров (srt, sub...).</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="107"/>
        <source>Left</source>
        <comment>horizontal alignment</comment>
        <translation>Слева</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="108"/>
        <source>Centered</source>
        <comment>horizontal alignment</comment>
        <translation>По центру</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="109"/>
        <source>Right</source>
        <comment>horizontal alignment</comment>
        <translation>Справа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="114"/>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation>Снизу</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="115"/>
        <source>Middle</source>
        <comment>vertical alignment</comment>
        <translation>По середине</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="116"/>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation>Сверху</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="121"/>
        <source>Outline</source>
        <comment>border style</comment>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="122"/>
        <source>Opaque box</source>
        <comment>border style</comment>
        <translation>Непрозрачный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="600"/>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the width of the outline around the text in pixels.</source>
        <translation>Если стиль границы установлен в &lt;i&gt;контур&lt;/i&gt;, эта опция определяет ширину контура вокруг текста в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="604"/>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the depth of the drop shadow behind the text in pixels.</source>
        <translation>Если стиль границы установлен в &lt;i&gt;непрозрачный&lt;/i&gt;, эта опция определяет длину тени за текстом в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="501"/>
        <source>Enable normal subtitles</source>
        <translation>Включить нормальные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="502"/>
        <source>Click this button to select the normal/traditional subtitles. This kind of subtitles can only display white subtitles.</source>
        <translation>Нажмите эту кнопку, чтобы выбрать нормальные/традиционные субтитры. Этот вид субтитров может отображать только белые субтитры.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="505"/>
        <source>Enable SSA/ASS subtitles</source>
        <translation>Включить SSA/ASS субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="509"/>
        <source>Normal subtitles</source>
        <translation>Нормальные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="528"/>
        <source>This option does NOT change the size of the subtitles in the current video. To do so, use the options &lt;i&gt;Size+&lt;/i&gt; and &lt;i&gt;Size-&lt;/i&gt; in the subtitles menu.</source>
        <translation>Эта опция не изменяет размер субтитров для текущего видео. Чтобы сделать это, используйте опции &lt;i&gt;Размер +&lt;/i&gt; и &lt;i&gt;Размер –&lt;/i&gt; в меню субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="532"/>
        <location filename="../prefsubtitles.cpp" line="544"/>
        <source>Default scale</source>
        <translation>Увеличение по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="533"/>
        <source>This option specifies the default font scale for normal subtitles which will be used for new opened files.</source>
        <translation>Эта опция определяет размер шрифта по умолчанию для нормальных субтитров, которое будет использовано для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="542"/>
        <source>SSA/ASS subtitles</source>
        <translation>SSA/ASS субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="545"/>
        <source>This option specifies the default font scale for SSA/ASS subtitles which will be used for new opened files.</source>
        <translation>Эта настройка определяет размер шрифта для субтиров SSA/ASS, который будет использоваться для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="549"/>
        <source>Line spacing</source>
        <translation>Междустрочный интервал</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="550"/>
        <source>This specifies the spacing that will be used to separate multiple lines. It can have negative values.</source>
        <translation>Здесь указывается интервал, который будет использоваться для разделения строк. Он может иметь отрицательные значения.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="280"/>
        <source>&amp;Font and colors</source>
        <translation>&amp;Шрифт и цвета</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="286"/>
        <source>Enable &amp;normal subtitles</source>
        <translation>Включить нор&amp;мальные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="299"/>
        <source>Enable SSA/&amp;ASS subtitles</source>
        <translation>Включить SSA/ASS субтитр&amp;ы</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="544"/>
        <source>Default s&amp;cale:</source>
        <translation>&amp;Увеличение по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="725"/>
        <source>Defa&amp;ult scale:</source>
        <translation>Увели&amp;чение по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="764"/>
        <source>&amp;Line spacing:</source>
        <translation>Междустрочный &amp;интервал:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="506"/>
        <source>Click this button to enable the new SSA/ASS library. This allows to display subtitles with multiple colors, fonts...</source>
        <translation>Нажмите эту кнопку, чтобы выбрать новую библиотеку SSA/ASS. Это позволяет использовать субтитры с разными цветами, шрифтами...</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="493"/>
        <source>Freetype support</source>
        <translation>Поддержка Freetype</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="494"/>
        <source>You should normally not disable this option. Do it only if your MPlayer is compiled without freetype support. &lt;b&gt;Disabling this option could make that subtitles won&apos;t work at all!&lt;/b&gt;</source>
        <translation>Обычно вы можете не отключать эту опцию. Делайт это только если MPlayer собран без поддержки freetype. &lt;b&gt;Отключение этой опции может привести к неработоспособности субтитров вообще!&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="256"/>
        <source>Freet&amp;ype support</source>
        <translation>Под&amp;держка Freetype</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="490"/>
        <source>If this option is checked, the subtitles will appear in the screenshots. &lt;b&gt;Note:&lt;/b&gt; it may cause some troubles sometimes.</source>
        <translation>Если выбрано, субтитры будут появляться на снимках экрана.&lt;b&gt; Примечание:&lt;/b&gt; иногда это может вызвать некоторые проблемы.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="607"/>
        <source>Apply style to ass files too</source>
        <translation>Применить стили также и для файлов ass</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="608"/>
        <source>If this option is checked, the style defined above will be applied to ass subtitles too.</source>
        <translation>Если эта опция выбрана, указанные стили будут также применены и к субтитрам в формате ass.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1211"/>
        <source>A&amp;pply style to ass files too</source>
        <translation>Применить стили также и для &amp;файлов ass</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="426"/>
        <source>Customize SSA/ASS style</source>
        <translation>Настроить стиль субтитров SSA/ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="427"/>
        <source>Here you can enter your customized SSA/ASS style.</source>
        <translation>Здесь можно указать предпочитаемый стиль субтитров SSA/ASS.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="428"/>
        <source>Clear the edit line to disable the customized style.</source>
        <translation>Очистите поле ввода, чтобы отменить настройки стиля.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="553"/>
        <source>SSA/ASS style</source>
        <translation>Стиль SSA/ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="575"/>
        <source>Shadow color</source>
        <translation>Цвет тени</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="576"/>
        <source>This color will be used for the shadow of the subtitles.</source>
        <translation>Этот цвет будет использован для тени субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="962"/>
        <source>Shadow:</source>
        <translation>Тень:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="1234"/>
        <source>Custo&amp;mize...</source>
        <translation>&amp;Настроить...</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <location filename="../preftv.cpp" line="42"/>
        <source>TV and radio</source>
        <translation>ТВ и радио</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="56"/>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="57"/>
        <source>Lowpass5</source>
        <translation>Lowpass5</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="58"/>
        <source>Yadif (normal)</source>
        <translation>Yadif (обычный)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="59"/>
        <source>Yadif (double framerate)</source>
        <translation>Yadif (2× частота кадров)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="60"/>
        <source>Linear Blend</source>
        <translation>Линейное смешивание</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="61"/>
        <source>Kerndeint</source>
        <translation>Адаптивное (mplayer)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="121"/>
        <source>Deinterlace by default for TV</source>
        <translation>Удаление &quot;гребёнки&quot; по умолчанию для ТВ</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="122"/>
        <source>Select the deinterlace filter that you want to be used for TV channels.</source>
        <translation>Выберите фильтр деинтерлейсинга (удаление &quot;гребёнки&quot;), который вы хотите использовать для ТВ-каналов.</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="125"/>
        <source>Rescan ~/.mplayer/channels.conf on startup</source>
        <translation>Пересканировать ~/.mplayer/channels.conf при старте</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="126"/>
        <source>If this option is enabled, ROSA Media Player will look for new TV and radio channels on ~/.mplayer/channels.conf.ter or ~/.mplayer/channels.conf.</source>
        <translation>Если эта опция выбрана, ROSA Media Player будет искать новые ТВ и радио каналы в ~/.mplayer/channels.conf.ter или ~/.mplayer/channels.conf.</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="32"/>
        <source>&amp;TV and radio</source>
        <translation>&amp;ТВ и радио</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="55"/>
        <source>Dei&amp;nterlace by default for TV:</source>
        <translation>&amp;Удаление &quot;гребёнки&quot; по умоланию для ТВ:</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="90"/>
        <source>&amp;Check for new channels on startup</source>
        <translation>&amp;Проверять на наличие новых каналов при старте</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="65"/>
        <location filename="../preferencesdialog.cpp" line="131"/>
        <source>ROSA Media Player - Help</source>
        <translation>ROSA Media Player – Помощь</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="135"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="136"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="137"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="138"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation>ROSA Media Player – Настройки</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>главное окно будет закрыто после окончания воспроизведения.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>будет показанно это сообщение, после чего приложение закроется.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>пытается соединиться с другим запущенным экземпляром и послать ему заданное действие. Пример: -send-action pause Остальные параметры (если есть) будут игнорироваться и приложение будет закрыто. При успешном выполнении задачи возвращается 0, или 1 в обратном случае.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>action_list – это список действий разделенный пробелами. Эти действия будут выполняться после загрузки файла в заданной вами последовательности. Для действий с переменными значениями можно использовать true или false в качестве параметров. Например: -actions &quot;fullscreen compact true&quot;. Кавычки необходимы в случае, если используется более одного действия.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation>определяет каталог, в котором rosa-media-player будет сохранять свои конфигурационные файлы (rosamp.ini, rosamp_files.ini...)</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>Если уже запущен экземпляр программы ,то файлы мультимедиа будут добавлены в существующий список. Если же нет – опция будет проигнорирована и файлы будут открыты в новом экземпляре.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>Главное окно не будет закрыто, по окончании файла/списка.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>Видео будет воспроизведиться в полноэкранном режиме.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>Видео будет воспроизводиться в оконном режиме.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation>&apos;media&apos; – любой вид файла, который может открыть ROSA Media Player. Это может быть локальный файл, DVD (т.е. dvd://1), интернет-поток (т.е. mms://...) или локальный список (плейлист) в формате m3u или pls. Если используется опция -playlist, это означает, что ROSA Media Player передаст эту опцию MPlayer-у и её воспримет он, а не ROSA Media Player.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Восстанавливает старые ассоциации и очищает реестр.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Использование:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>каталог</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>имя_действия</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>список_действий</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>открывает интерфейс по умолчанию.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>файл_субтитров</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>Указывает файл субтитров, который будет загружен для первого видеофайла.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation>
            <numerusform>%1 секунда</numerusform>
            <numerusform>%1 секунды</numerusform>
            <numerusform>%1 секунд</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation>
            <numerusform>%1 минута</numerusform>
            <numerusform>%1 минуты</numerusform>
            <numerusform>%1 минут</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>отключено</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>авто</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>неизвестно</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation>ширина</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation>высота</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>указывает координаты верхнего левого угла главного окна приложения.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation>указывает размер главного окна.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="445"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation>ROSA Media Player запущен в %1</translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation>Добавить в ROSA Media Player</translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>Ошибка ZIP/UNZIP API %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="94"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation>Не удалось начать запись. Проверьте, установлен ли ffmpeg.</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="97"/>
        <source>Unknown error in recording occured</source>
        <translation>Неизвестная ошибка записи</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="100"/>
        <source>Sorry, recording crashed</source>
        <translation>Извините, ошибка записи</translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="49"/>
        <source>/Screencast - </source>
        <translation>/Экранная презентация - </translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation>Экранная презентация успешно сохранена в %1</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="86"/>
        <source>Length: %1
Size: %2
</source>
        <translation>Длина: %1
Размер: %2
</translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>метка</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Изменить сочетание клавиш</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Нажмите клавиши, сочетание которых вы хотите использовать</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Захват</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Горячая клавиша снимка с экрана</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation>Начальное время обрезки должно быть меньше конечного</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation>/Видео_</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation>Невозможно обрезать видео ( возможно не хватает места на диске? )</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation>Невозможно обрезать видео (код: %1)</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>Новый файл &quot;%1&quot; сохранен в каталоге %2</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation>Обрезать видео</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation>Укажите временной интервал:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation>С:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation>Установить текущее время воспроизведения</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation>По:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation>Обрезать</translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Выбор субтитров</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Этот архив содержит более одного файла субтиров. Выберите необходимый вам для распаковки.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Ничего не выбирать</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="97"/>
        <source>Channel editor</source>
        <translation>Редактор каналов</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="98"/>
        <source>TV/Radio list</source>
        <translation>Список ТВ/Радио</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Перейти к:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Авто</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="74"/>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Contrast</source>
        <translation>Контрастность</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Hue</source>
        <translation>Оттенок</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Gamma</source>
        <translation>Гамма</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Установки по умолчанию</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать данные настройки по умолчанию для новых файлов.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Установить все значения в ноль.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="71"/>
        <source>Video Equalizer</source>
        <translation>Видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="122"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="123"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Текущие параметры были сохранены как используемые по умолчанию.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="136"/>
        <location filename="../videopreview/videopreview.cpp" line="397"/>
        <source>Video preview</source>
        <translation>Предпросмотр видео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="228"/>
        <source>Creating thumbnails...</source>
        <translation>Создание миниатюр...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="381"/>
        <source>Size: %1 MB</source>
        <translation>Размер: %1 MB</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Length: %1</source>
        <translation>Продолжительность: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="525"/>
        <source>Save file</source>
        <translation>Сохранить файл</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="533"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранен</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="184"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>При создании миниатюр произошла следующая ошибка:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="211"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>Не удалось создать временную папку (%1)</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="306"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>Процесс mplayer не был запущен</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Resolution: %1x%2</source>
        <translation>Разрешение: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="386"/>
        <source>Video format: %1</source>
        <translation>Формат видео: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Frames per second: %1</source>
        <translation>Кадров в секунду: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Aspect ratio: %1</source>
        <translation>Соотношение сторон: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="324"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>Не удалось загрузить файл %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="423"/>
        <source>No filename</source>
        <translation>Не указано имя файла</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="483"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Процесс mplayer не был запущен при получении информации о видео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="202"/>
        <source>The length of the video is 0</source>
        <translation>Длительность видео 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="246"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>Файл %1 не существует</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="370"/>
        <source>No info</source>
        <translation>Нет информации</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="139"/>
        <source>Generated by ROSA Media Player</source>
        <translation>Сгенерировано ROSA Media Player-ом</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="373"/>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <source>%1 kbps</source>
        <translation>%1 кб/с</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="391"/>
        <source>Video bitrate: %1</source>
        <translation>Видео битрейт: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Audio bitrate: %1</source>
        <translation>Аудио битрейт: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio rate: %1</source>
        <translation>Частота выборки аудио: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation>Предпросмотр</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation>&amp;Файл:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation>Стол&amp;бцы:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation>Стро&amp;ки:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation>&amp;Соотношение сторон:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation>Время &amp;первой миниатюры:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation>&amp;Максимальная ширина:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>Окно предпросмотра будет создано для указанного здесь файла.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Миниатюры будут сгруппированы в таблицу.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Эта опция определяет столбцов в таблице.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Эта опция определяет количество строк в таблице.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Если вы отметите эту опцию, время будет отображаться внизу каждой миниатюры.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Если соотношение сторон видео неправильное, здесь можно указать другое.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Обычно первые кадры чёрные, поэтому неплохой идеей будет пропустить несколько секунд в начале видео. Эта опция определяет, сколько секунд будет пропущено.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Эта опция указывает максимальную ширину в пикселах, которую будет иметь сгенерированное изображение.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Некоторые кадры будут извлечены из видео для создания миниатюр. Здесь вы можете выбрать формат извлекаемых изображений. PNG может дать лучшее качество.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Добавить&amp; время на миниатюрах</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation>Извлечь кадры &amp;как</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Укажите здесь устройство DVD или каталог с образом DVD.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation>Устройст&amp;во DVD:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Запоминать каталог для &amp;сохранения предпросмотра</translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
</context>
</TS>
