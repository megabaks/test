#ifndef SUBWINDOW_H
#define SUBWINDOW_H

#include <QWidget>

class SubWindow : public QWidget
{
    Q_OBJECT
public:
    explicit SubWindow(QWidget *parent = 0);
    
Q_SIGNALS:
    
public Q_SLOTS:
    
};

#endif // SUBWINDOW_H
