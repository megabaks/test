#include "subwindow.h"

SubWindow::SubWindow(QWidget *parent) :
    QWidget(parent)
{
}
