<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ku_IR">
<context>
    <name>Core</name>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="199"/>
        <source>Connecting to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="203"/>
        <source>Unable to retrieve youtube page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="207"/>
        <source>Unable to locate the url of the video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="1214"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="1230"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="2872"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="2891"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="2909"/>
        <source>A-B markers cleared</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3152"/>
        <source>Brightness: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3169"/>
        <source>Contrast: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3185"/>
        <source>Gamma: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3201"/>
        <source>Hue: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3217"/>
        <source>Saturation: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3282"/>
        <source>Speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3369"/>
        <source>Volume: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3418"/>
        <source>Subtitle delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3438"/>
        <source>Audio delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3507"/>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3525"/>
        <source>Font scale: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3579"/>
        <source>Subtitles on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="3581"/>
        <source>Subtitles off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4189"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4240"/>
        <source>Mouse wheel seeks now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4243"/>
        <source>Mouse wheel changes volume now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4246"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4249"/>
        <source>Mouse wheel changes speed now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4335"/>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/core.cpp" line="4605"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../romp/rosa-media-player/src/filters.cpp" line="34"/>
        <source>add noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/filters.cpp" line="35"/>
        <source>deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MiniControlPanel</name>
    <message>
        <location filename="../rosamp-plugin/minicontrolpanel.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/minicontrolpanel.ui" line="62"/>
        <location filename="../rosamp-plugin/minicontrolpanel.ui" line="189"/>
        <location filename="../rosamp-plugin/minicontrolpanel.ui" line="274"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/minicontrolpanel.ui" line="98"/>
        <location filename="../rosamp-plugin/minicontrolpanel.ui" line="154"/>
        <source>00:00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/minicontrolpanel.cpp" line="89"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message numerus="yes">
        <location filename="../romp/rosa-media-player/src/helper.cpp" line="88"/>
        <location filename="../romp/rosa-media-player/src/helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../romp/rosa-media-player/src/helper.cpp" line="93"/>
        <location filename="../romp/rosa-media-player/src/helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../romp/rosa-media-player/src/mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RosampPlugin</name>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="248"/>
        <source>ROSA Media Player Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="249"/>
        <source>&lt;span style=&quot;font-weight:bold;font-size:14pt&quot;&gt;ROSA Media Player Plugin %1&lt;/span&gt;&lt;br&gt;&lt;br&gt;Copyright &amp;copy; ROSA 2011&lt;br&gt;&lt;span style=&quot;font-size:8pt&quot;&gt;Authors: Evgeniy Augin, Julia Mineeva, Sergey Borovkov&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="252"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="281"/>
        <source>Copy url...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="282"/>
        <source>Open video in ROSA Media Player...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="283"/>
        <source>About &amp;plugin...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VolumeControl</name>
    <message>
        <location filename="../rosamp-plugin/volumecontrol.cpp" line="77"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
