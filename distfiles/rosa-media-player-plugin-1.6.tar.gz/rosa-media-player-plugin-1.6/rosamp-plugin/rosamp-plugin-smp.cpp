/* ROSA Media Player plugin
 * Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


#include "rosamp-plugin-smp.h"


RosampPluginSmp::RosampPluginSmp( QWidget* parent )
    : RosampPlugin( parent )
{
}

RosampPluginSmp::~RosampPluginSmp()
{
}

QTNPFACTORY_BEGIN("ROSA Media Player Plug-in", "A ROSA Media Player plug-in")
QTNPCLASS(RosampPluginSmp)
QTNPFACTORY_END()

#ifdef QAXSERVER
#include <ActiveQt/QAxFactory>
QAXFACTORY_BEGIN("{aa3216bf-7e20-482c-84c6-06167bacb616}", "{08538ca5-eb7a-4f24-a3c4-a120c6e04dc4}")
QAXCLASS(RosampPluginSmp)
QAXFACTORY_END()
#endif

