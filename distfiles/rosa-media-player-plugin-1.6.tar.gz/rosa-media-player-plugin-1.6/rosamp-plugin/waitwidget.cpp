/* ROSA Media Player Plugin
 * Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "waitwidget.h"

#include <QMovie>
#include <QLabel>

#include <QRegion>
#include <QPainter>
#include <QPoint>
#include <QPen>
#include <QBoxLayout>

WaitWidget::WaitWidget(QWidget* parent)
    : QWidget(parent)
{
    setGeometry(0, 0, 50, 50);
    setAutoFillBackground(true);

    setBorderRadius(3);

    m_movie = new QMovie(":/images/loader-transparent.gif");
    m_label = new QLabel(this);
    m_label->setMovie(m_movie);

    QBoxLayout* layout = new QBoxLayout(QBoxLayout::LeftToRight, this);
    layout->addWidget(m_label);

    m_movie->start();

    setLayout(layout);
}

void WaitWidget::initForm()
{
    QRegion region(0, 0, width(), height(), QRegion::Rectangle);

    // top left
    QRegion round (0, 0 - width() / 2, width(), width() * 2, QRegion::Ellipse);

    region = region.intersected(round);
    setMask(region);
}

void WaitWidget::paintEvent(QPaintEvent* e)
{
    Q_UNUSED( e );

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setRenderHint(QPainter::HighQualityAntialiasing);

    QPoint p1(rect().width() / 2, 0);
    QPoint p2(rect().width() / 2, (rect().height()));
    QLinearGradient fade(p1, p2);
    QColor color(60, 60, 60, 255);

    fade.setColorAt(0.0, color);
    fade.setColorAt(1.0, Qt::black);
    painter.fillRect(rect(), fade);

    QPen pen;
    pen.setWidth(2);
    pen.setBrush(Qt::white);
    pen.setCapStyle(Qt::RoundCap);
    pen.setJoinStyle(Qt::RoundJoin);

    painter.setPen(pen);
    painter.drawRoundedRect(this->contentsRect(), 5, 5);
}

void WaitWidget::setBorderRadius( int radius )
{
    QRegion region(0, 0, width(), height(), QRegion::Rectangle);

    // top left
    QRegion round (0, 0, 2 * radius, 2 * radius, QRegion::Ellipse);
    QRegion corner(0, 0, radius, radius, QRegion::Rectangle);
    region = region.subtracted(corner.subtracted(round));

    // top right
    round = QRegion(width() - 2 * radius, 0, 2 * radius, 2 * radius, QRegion::Ellipse);
    corner = QRegion(width() - radius, 0, radius, radius, QRegion::Rectangle);
    region = region.subtracted( corner.subtracted( round));

    // bottom right
    round = QRegion(width() - 2 * radius, height() - 2 * radius, 2 * radius, 2 * radius, QRegion::Ellipse);
    corner = QRegion(width() - radius, height() - radius, radius, radius, QRegion::Rectangle);
    region = region.subtracted(corner.subtracted(round));

    // bottom left
    round = QRegion(0, height() - 2 * radius, 2 * radius, 2 * radius, QRegion::Ellipse);
    corner = QRegion(0, height() - radius, radius, radius, QRegion::Rectangle);
    region = region.subtracted(corner.subtracted(round));

    setMask(region);
}

void WaitWidget::showEvent (QShowEvent* event)
{
    raise();
}
