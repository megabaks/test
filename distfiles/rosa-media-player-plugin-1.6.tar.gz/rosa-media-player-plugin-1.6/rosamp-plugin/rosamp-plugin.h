/*  ROSA Media Player plugin
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef ROSAMPPLUGIN_H
#define ROSAMPPLUGIN_H

#include <QtGui>

#include "qtbrowserplugin/qtbrowserplugin.h"

#ifdef QAXSERVER
#include <ActiveQt/QAxBindable>
#include <ActiveQt/QAxFactory>
#include <qt_windows.h>
#endif

class QTimer;
class QToolBar;
class MySlider;
class VolumeControl;
class WaitWidget;

class Core;
class SmplayerCoreLib;
class FullScreenWidget;
class MiniControlPanel;
class QToolBox;
class Translator;

extern Translator * translator;


class RosampPlugin : public QMainWindow, public QtNPBindable
#ifdef QAXSERVER
    , public QAxBindable
#endif
{
    Q_OBJECT
    Q_PROPERTY(QString src READ dataSourceUrl WRITE setDataSourceUrl)
    Q_PROPERTY(QString data READ dataSourceUrl WRITE setDataSourceUrl)
    Q_PROPERTY(QString width READ dataVideoWidth WRITE setDataVideoWidth)
    Q_PROPERTY(QString height READ dataVideoHeight WRITE setDataVideoHeight)

    Q_CLASSINFO("DefaultProperty", "src")

public:
    RosampPlugin(QWidget *parent = 0);
    ~RosampPlugin();

    void setDataSourceUrl(const QString& url);
    QString dataSourceUrl() const;

    void setDataVideoWidth(const QString& w);
    QString dataVideoWidth() const;

    void setDataVideoHeight(const QString& h);
    QString dataVideoHeight() const;

    bool readData(QIODevice* source, const QString& format);
    bool writeData(QIODevice* sink);

    void transferComplete(const QString& url, int id, Reason r);

    QTimer* hideTimer();    

signals:
    void cachePercent(int);

protected:    
    void createMenus();
    void createToolBar();
    void initWaitControl();

    void mousePressEvent(QMouseEvent*);
    void mouseMoveEvent(QMouseEvent*);
    void resizeEvent (QResizeEvent*);
    virtual void closeEvent(QCloseEvent* event);

private slots:
    void copyUrl();
    void openVideo();
    void aboutPlugin();    
    void mediaLoadedSlot();
    void setResolution(int);
    void toggleFullScreen();
    void getMessage(QString);
    void showWaitWidget( bool );

private:
    static int m_counterInstances;      // counter for instances of plugin widgets

    QToolBar* m_toolbar;

    QLabel* m_animationLabel;
    QMovie* m_movie;

    // Developer information for the About Data dialog:
    QString m_sourceUrl;
    int m_videoWidth;
    int m_videoHeight;

    Core*               m_core;
    SmplayerCoreLib*    m_smplayerlib;

    QMenu*              m_menu;
    QToolBar*           m_miniPanel;
    QTimer*             m_hideTimer;

    FullScreenWidget*   m_fullScreenWidget;
    bool                m_fullScreenEnabled;
    MiniControlPanel*   m_mini;

    WaitWidget*         m_waitWidget;

};

#endif // ROSAMPPLUGIN_H
