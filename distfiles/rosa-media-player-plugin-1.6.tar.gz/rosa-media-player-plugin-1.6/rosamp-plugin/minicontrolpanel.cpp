/* ROSA Media Player Plugin
 * Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "minicontrolpanel.h"
#include "ui_minicontrolpanel.h"
#include "myslider.h"
#include "global.h"
#include "preferences.h"
#include "volumebutton.h"

#include <QtSvg/QSvgRenderer>
#include <QPainter>
#include <QPixmap>
#include <QImage>
#include <QTime>
#include <QBoxLayout>
#include <QDebug>
#include <QTimer>
#include <QtCore/QSettings>

#include <math.h>

using namespace Global;

MiniControlPanel::MiniControlPanel(Core* core, QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MiniControlPanel)
    , m_core(core)
    , m_soundMuted(false)
{
    ui->setupUi(this);

    setMouseTracking(true);

    ui->playButton->setEnabled(false);
    ui->playButton->setIconSize(QSize(24,24));

    connect(ui->playButton, SIGNAL(clicked(bool)), SLOT(playClicked()));

    connect(m_core, SIGNAL(stateChanged(Core::State)), SLOT(updatePlayButton(Core::State)));
    connect(m_core, SIGNAL(mediaLoaded()), SLOT(enableActionsOnPlaying()));
    connect(m_core, SIGNAL(mediaFinished()), SLOT(disableActionsOnStop()), Qt::QueuedConnection);
    connect(m_core, SIGNAL(mediaStoppedByUser()), SLOT(disableActionsOnStop()));

    connect(ui->volumeButton, SIGNAL(clicked()), SLOT(volumeButtonClicked()));
    ui->volumeButton->setIconSize(QSize(24,24));

    connect(ui->fullScreenButton, SIGNAL(clicked()), SLOT(toggleFullScreen()));    
    ui->fullScreenButton->setIconSize(QSize(24,24));

    // Init time slider
    ui->timeSlider->setDragDelay(pref->time_slider_drag_delay);

    connect(ui->timeSlider, SIGNAL(posChanged(int)), SLOT(goToPosition(int)));
    connect(ui->timeSlider, SIGNAL(delayedDraggingPos(int)), SLOT(goToPosOnDragging(int)));

    connect(m_core, SIGNAL(positionChanged(int)), ui->timeSlider, SLOT(setPos(int)));
    connect(m_core, SIGNAL(showTime(double)), SLOT(updateTimeSlider(double)));

    // timer for seek command bug (turn on when does'not come reply from mplayer)
    m_hideWaitWidgetTimer = new QTimer(this);
    connect( m_hideWaitWidgetTimer, SIGNAL(timeout()), SLOT(hideWaitWidgetSlot()));

    ui->volumeSlider->setMinimum(0);
    ui->volumeSlider->setMaximum(100);
    ui->volumeSlider->setOrientation(Qt::Horizontal);
    ui->volumeSlider->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    ui->volumeSlider->setFocusPolicy(Qt::NoFocus);
    ui->volumeSlider->setTickPosition(QSlider::NoTicks);
    ui->volumeSlider->setTickInterval(10);
    ui->volumeSlider->setSingleStep(1);
    ui->volumeSlider->setPageStep(10);
    ui->volumeSlider->setToolTip(tr("Volume"));
    ui->volumeSlider->setAttribute( Qt::WA_NoMousePropagation );
    ui->volumeSlider->setEnabled(true);
    ui->volumeSlider->setCore(m_core);
    ui->volumeSlider->setGeometry( 200, 100, 26, 100 );

    connect(ui->volumeSlider, SIGNAL(valueChanged(int)), SLOT(updateVolume(int)));
    connect(ui->volumeSlider, SIGNAL(clicked()), SLOT(checkMute()));
}

MiniControlPanel::~MiniControlPanel()
{
    delete ui;
    delete m_hideWaitWidgetTimer;
}

void MiniControlPanel::paintEvent(QPaintEvent *)
{
    QPixmap p(":background.png");
    QImage image = p.toImage();

    QPainter painter(this);
    painter.drawImage(rect(), image);
}

void MiniControlPanel::updateVolumeSlider(int v)
{
    ui->volumeSlider->setValue(v);
}

void MiniControlPanel::updateVolume(int v)
{
//    if(m_soundMuted) {
//        ui->volumeButton->setIcon(QIcon(":sound1.png"));
//        m_soundMuted = false;
//        m_core->switchMute();
//    }
    m_core->setVolume(v);
    QSettings settings("ROSA", "Rosa-Media-Player-plugin");
    settings.setValue("volume/value", v);
}

void MiniControlPanel::goToPosition(int pos)
{
    ui->timeSlider->setPos(pos);

    // make checking for stream type because stream is slow
    // and we must show animation while download video
    if (m_core->mdat.type != TYPE_STREAM) {
        // simply make seek
        m_core->goToPosition(pos);
        return;
    }

    // wait "PLAY" event
    disconnect(m_core, SIGNAL(stateChanged(Core::State)), this, SLOT(updatePlayButton(Core::State)));

    // set video to pause
    m_core->pause();

    // set to new seek position
    m_core->goToPosition(pos);

    // block time slider until come "PLAY" event
    ui->timeSlider->setEnabled(false);
    //ui->resolutionButton->setEnabled(false);

    // show animation widget
    m_isSeeking = true;
    emit isSeeking(m_isSeeking);

    connect(m_core, SIGNAL(stateChanged(Core::State)), SLOT(receiveStateChangedEvent(Core::State)));

    if (m_hideWaitWidgetTimer->isActive())
        m_hideWaitWidgetTimer->stop();
    m_hideWaitWidgetTimer->start(2000);
}

/* restore state of time slider */
void MiniControlPanel::receiveStateChangedEvent(Core::State state)
{
    if (state != Core::Playing)
        return;

    // working as usually
    disconnect(m_core, SIGNAL(stateChanged(Core::State)), this, SLOT(receiveStateChangedEvent(Core::State)));

    updatePlayButton(state);

    // unblock time slider
    ui->timeSlider->setEnabled(true);
    //ui->resolutionButton->setEnabled(true);

    // hide animation widget
    m_isSeeking = false;
    emit isSeeking(m_isSeeking);

    connect(m_core, SIGNAL(stateChanged(Core::State)), SLOT(updatePlayButton(Core::State)));

    if (m_hideWaitWidgetTimer->isActive())
        m_hideWaitWidgetTimer->stop();
}

/* update time information on the control panel */
void MiniControlPanel::updateTimeSlider(double sec)
{
    static int last_second = 0;
    if (floor (sec) == last_second)
        return;
    last_second = (int) floor(sec);

    // processed time
    QTime t(0, 0, 0);
    t = t.addSecs((int)sec);
    QString str = (sec >= 3600) ? "hh:mm:ss" : "mm:ss";
    ui->timeLabel->setText(t.toString(str));

    // rest time
    t.setHMS(0, 0, 0);
    t = t.addSecs((int) (m_core->mdat.duration));
    if ((m_core->mdat.duration) >= 3600)
    {
        str = (m_core->mdat.type == TYPE_STREAM) ? "00:00" : "hh:mm:ss";
        ui->allTimeLabel->setText(str);
    }
    else
        ui->allTimeLabel->setText(t.toString("mm:ss"));
}

void MiniControlPanel::goToPosOnDragging(int t)
{
    if (pref->update_while_seeking)
        m_core->goToPosition(t);
}

/* change play state */
void MiniControlPanel::playClicked()
{
    if (!m_core)
        return;
    if (m_core->state() == Core::Playing)
        m_core->pause();
    else
        m_core->play();
}

void MiniControlPanel::updatePlayButton(Core::State state)
{
    if (state == Core::Playing)
        ui->playButton->setIcon(QPixmap(":pause.png"));
    else
        ui->playButton->setIcon(QPixmap(":play.png"));

    repaint();
}

void MiniControlPanel::disableActionsOnStop()
{
    ui->timeSlider->setEnabled(false);
}

void MiniControlPanel::enableActionsOnPlaying()
{
    ui->playButton->setEnabled(true);
    ui->timeSlider->setEnabled(true);
}

void MiniControlPanel::toggleFullScreen()
{
    emit setFullScreen();
}

void MiniControlPanel::toggleFullScreenMode(bool enable)
{
    if (enable)
        ui->fullScreenButton->setIcon(QIcon(":mini.resume.png"));
    else
        ui->fullScreenButton->setIcon(QIcon(":mini.full.png"));
}

void MiniControlPanel::setSliderEnabled(bool enable)
{
    ui->timeSlider->setEnabled(enable);
}

void MiniControlPanel::hideWaitWidgetSlot()
{
    if (m_isSeeking && (m_core->state() == Core::Playing)) {
        m_hideWaitWidgetTimer->stop();
        receiveStateChangedEvent(m_core->state());
    }
    else {
        m_hideWaitWidgetTimer->start( 2000 );
    }
}

void MiniControlPanel::volumeButtonClicked()
{
    m_core->switchMute();

    if(!m_soundMuted) {
        ui->volumeButton->setIcon(QIcon(":sound0.png"));
        m_soundMuted = true;
        m_volume = ui->volumeSlider->value();
        ui->volumeSlider->setValue(0);
    }
    else {
        ui->volumeButton->setIcon(QIcon(":sound1.png"));
        m_soundMuted = false;
        ui->volumeSlider->setValue(m_volume);
    }
}

void MiniControlPanel::checkMute()
{
    if(m_soundMuted) {
        m_core->switchMute();
        ui->volumeButton->setIcon(QIcon(":sound1.png"));
        m_soundMuted = false;        
    }
}
