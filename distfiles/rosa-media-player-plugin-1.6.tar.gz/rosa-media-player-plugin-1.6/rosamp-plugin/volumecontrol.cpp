/* ROSA Media Player Plugin
 * Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "volumecontrol.h"
#include "myslider.h"
#include "core.h"

#include <QBoxLayout>

VolumeControl::VolumeControl(Core *core, QWidget* parent)
    : MySlider(parent)
{
    init();
    setCore(core);
}

VolumeControl::VolumeControl(QWidget* parent)
    : MySlider(parent)
{
    init();
}

void VolumeControl::setCore(Core *core)
{
    m_core = core;
    setValue(m_core->mset.volume);
    connect(this, SIGNAL(valueChanged(int)), SLOT(updateVolume(int)));
    connect(m_core, SIGNAL(volumeChanged(int)), SLOT(updateVolumeSlider(int)));
}

void VolumeControl::updateVolumeSlider(int v)
{
    setValue(v);

    if (( v > 66) && (v <= 100))
        emit changeVolumeIcon(3);
    else if ((v > 33) && (v <= 66))
        emit changeVolumeIcon(2);
    else if ((v > 0) && (v <= 33))
        emit changeVolumeIcon(1);
    else
        emit changeVolumeIcon(0);
}

void VolumeControl::updateVolume(int v)
{
    m_core->setVolume(v);
}

void VolumeControl::init()
{
    setOrientation(Qt::Horizontal);
    setValue(50);
    setMinimum(0);
    setMaximum(100);
    setFocusPolicy(Qt::NoFocus);
    setTickPosition(QSlider::NoTicks);
    setTickInterval(10);
    setSingleStep(1);
    setPageStep(10);
    setToolTip(tr("Volume"));
}
