/*  ROSA Media Player plugin
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef MINICONTROLPANEL_H
#define MINICONTROLPANEL_H

#include <QWidget>
#include <QObject>

#include "core.h"

class MySlider;
class QTimer;

namespace Ui
{
class MiniControlPanel;
}

class MiniControlPanel : public QWidget
{
    Q_OBJECT

public:
    explicit MiniControlPanel( Core* core, QWidget* parent = 0 );
    ~MiniControlPanel();

    bool isSeeking() const { return m_isSeeking; }
    void setSliderEnabled(bool enable);

public slots:
    void toggleFullScreenMode(bool);
    void receiveStateChangedEvent(Core::State);
    void updateVolume(int v);
    void updateVolumeSlider(int v);

protected:
    void paintEvent(QPaintEvent *);

private slots:
    void goToPosition( int );
    void goToPosOnDragging( int );

    void updateTimeSlider( double );

    void playClicked();
    void updatePlayButton( Core::State );

    void enableActionsOnPlaying();
    void disableActionsOnStop();

    void toggleFullScreen();

    void volumeWheelControl( int );    

    void hideWaitWidgetSlot();

    void volumeButtonClicked();
    void checkMute();

signals:
    void showVolumeSlider( int, int );
    void setFullScreen();
    void isSeeking( bool );
    void hideVolumeWindow();

private:
    Ui::MiniControlPanel *ui;
    QWidget *m_volumeWidget;
    MySlider *m_volumeSlider;
    Core* m_core;
    QTimer *m_hideWaitWidgetTimer;
    int m_volume;

    bool m_isSeeking;
    bool m_soundMuted;
};

#endif // MINICONTROLPANEL_H
