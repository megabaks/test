/* ROSA Media Player Plugin
 * Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "fullscreenwidget.h"
#include "rosamp-plugin.h"
#include "minicontrolpanel.h"
#include "core.h"
#include "volumecontrol.h"
#include "waitwidget.h"

#include <QAction>
#include <QKeyEvent>
#include <QBoxLayout>

FullScreenWidget::FullScreenWidget(QMenu* menu, Core* core, WaitWidget* waitWidget, QWidget* parent)
    : QWidget(parent)
    , m_control(0)
    , m_menu(menu)
    , m_core(core)
    , m_connectFlag(false)
    , m_waitWidget(waitWidget)
{
    m_hideTimer = new QTimer(this);
    connect(m_hideTimer, SIGNAL(timeout()), SLOT(hideControlSlot()));
    setMouseTracking(true);
}

void FullScreenWidget::keyPressEvent(QKeyEvent *e)
{
    if (e->key() == Qt::Key_Escape)
        emit offFullScreen();
}

void FullScreenWidget::setControl(MiniControlPanel* form)
{
    setMouseTracking(true);
    m_control = form;
    if (!m_connectFlag) {
        m_connectFlag = true;
    }

    QRect rect = QApplication::desktop()->screenGeometry();
    m_control->setGeometry(0, rect.height() - m_control->height(), rect.width(), m_control->height());
    m_control->show();
}

void FullScreenWidget::mouseMoveEvent(QMouseEvent *e)
{
    QRect rect = QApplication::desktop()->screenGeometry();
    QRect CPRect(0, rect.height() - m_control->height(), rect.width(), m_control->height());
    if (CPRect.contains(e->pos())) {
        m_hideTimer->stop();
        if (!m_control->isVisible())
            m_control->show();
    }
    else {
        if (!m_hideTimer->isActive())
            m_hideTimer->start(3000);
    }
}

void FullScreenWidget::mousePressEvent( QMouseEvent* e )
{
    if (e->button() == Qt::RightButton && m_menu)
        m_menu->exec(e->globalPos());
}

void FullScreenWidget::hideControlSlot()
{
    if (m_waitWidget->isVisible())
        m_hideTimer->start(3000);
    else
        m_control->hide();
}

void FullScreenWidget::hide()
{
    setMouseTracking(false);

    if (m_hideTimer->isActive())
        m_hideTimer->stop();

    QWidget::hide();
}
