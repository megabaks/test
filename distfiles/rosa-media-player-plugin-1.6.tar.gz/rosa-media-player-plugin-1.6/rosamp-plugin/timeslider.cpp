/*  ROSA Media Player plugin
    Copyright (C) 2006-2010 Ricardo Villalba <rvm@escomposlinux.org>
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* This is based on smplayer class TimeSlider */

#include "timeslider.h"

#include <QWheelEvent>
#include <QTimer>

#define DEBUG 0

TimeSlider::TimeSlider(QWidget *parent)
    : MySlider(parent)
{
    dont_update = FALSE;
    setMinimum(0);
#ifdef SEEKBAR_RESOLUTION
    setMaximum(SEEKBAR_RESOLUTION);
#else
    setMaximum(100);
#endif

    setFocusPolicy(Qt::NoFocus);
    setSizePolicy(QSizePolicy::Expanding , QSizePolicy::Fixed);

    connect(this, SIGNAL(sliderPressed()), SLOT(stopUpdate()));
    connect(this, SIGNAL(sliderReleased()), SLOT(resumeUpdate()));
    connect(this, SIGNAL(sliderReleased()), SLOT(mouseReleased()));
    connect(this, SIGNAL(valueChanged(int)), SLOT(valueChanged_slot(int)));
#if ENABLE_DELAYED_DRAGGING
    connect(this, SIGNAL(draggingPos(int)), SLOT(checkDragging(int)));

    last_pos_to_send = -1;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), SLOT(sendDelayedPos()));
    timer->start(200);
#endif
}

void TimeSlider::stopUpdate()
{
#if DEBUG
    qDebug("TimeSliderEx::stopUpdate");
#endif
    dont_update = TRUE;
}

void TimeSlider::resumeUpdate()
{
#if DEBUG
    qDebug("TimeSliderEx::resumeUpdate");
#endif
    dont_update = FALSE;
}

void TimeSlider::mouseReleased()
{
#if DEBUG
    qDebug("TimeSliderEx::mouseReleased");
#endif
    emit posChanged(value());
}

void TimeSlider::valueChanged_slot(int v)
{
#if DEBUG
    qDebug("TimeSliderEx::changedValue_slot: %d", v);
#endif

    // Only to make things clear:
    bool dragging = dont_update;
    if (!dragging) {
        if (v != position) {
#if DEBUG
            qDebug(" emitting posChanged");
#endif
            emit posChanged(v);
        }
    }
    else {
#if DEBUG
        qDebug(" emitting draggingPos");
#endif
        emit draggingPos(v);
    }
}

#if ENABLE_DELAYED_DRAGGING
void TimeSlider::setDragDelay(int d)
{
    qDebug("TimeSliderEx::setDragDelay: %d", d);
    timer->setInterval(d);
}

int TimeSlider::dragDelay()
{
    return timer->interval();
}

void TimeSlider::checkDragging(int v)
{
    qDebug("TimeSliderEx::checkDragging: %d", v);
    last_pos_to_send = v;
}

void TimeSlider::sendDelayedPos()
{
    if (last_pos_to_send != -1)
    {
        qDebug("TimeSliderEx::sendDelayedPos: %d", last_pos_to_send);
        emit delayedDraggingPos(last_pos_to_send);
        last_pos_to_send = -1;
    }
}
#endif

void TimeSlider::setPos(int v)
{
#if DEBUG
    qDebug("TimeSliderEx::setPos: %d", v);
    qDebug(" dont_update: %d", dont_update);
#endif

    if (v!=pos())
    {
        if (!dont_update)
        {
            position = v;
            setValue(v);
        }
    }
}

int TimeSlider::pos()
{
    return position;
}

void TimeSlider::wheelEvent( QWheelEvent * e )
{
    e->ignore();
}
