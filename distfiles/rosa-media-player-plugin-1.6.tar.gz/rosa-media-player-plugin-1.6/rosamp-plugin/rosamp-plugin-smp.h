/*  ROSA Media Player plugin
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef ROSAMPPLUGINSMP_H
#define ROSAMPPLUGINSMP_H

#include "rosamp-plugin.h"


class RosampPluginSmp : public RosampPlugin
{
    Q_OBJECT

    Q_CLASSINFO( "MIME",
                 // MPEG
                 "video/mpeg:mpg, mpeg:MPEG;"
                 "video/x-mpeg:mpg,mpeg:MPEG;"
                 "video/x-mpeg2:mpv2,mp2ve:MPEG2;"
                 "video/mp4:mp4:MPEG 4 Video;"
                 "video/x-m4v:m4v:MPEG 4 Video;"
                 "video/3gpp:mp4,3gp:MPEG 4 Video;"

                 // VLC Multimedia file formats
                 "application/x-winamp:nsv: video Nullsoft Streaming Video;"
                 "application/x-nsv-vp3-mp3:nsv:Nullsoft Streaming Video;"
                 "video/x-nsv:nsv:Nullsoft Streaming Video;"

                 // FLV
                 "video/flv:flv:Flash Video;"
                 "video/x-flv:flv:Flash Video;"

                 // FLI
                 "video/flc:fli, flc:FLI animation;"
                 "video/x-flic:fli, flc:FLI animation;"
                 "video/fli:fli:FLI animation;"
                 "video/x-fli:fli:FLI animation;"

                 // OGM
                 "application/ogg:ogm, ogg:video/audio Ogg Media;"
                 "video/ogg:ogg, ogm:Ogg Vorbis Video;"
                 "video/x-ogg:ogg, ogm:Ogg Vorbis Video;"
                 "application/ogg:ogg, oga, ogm:Ogg Vorbis Audio;"
                 "application/x-ogg:ogg, oga, ogm:Ogg Vorbis Audio;"

                 // NuppelVideo
                 "video/x-nuv:nuv:video NuppelVideo;"

                 /* DELETED because we can't open (download) iso, md5sum files */
                 /*
                 // yuv4mpeg
                         "application/octet-stream:yuv:video YUV;"

                 // FILM (.cpk) ?????????? extension ???????????
                         "application/octet-stream:film_cpk, cpk:video Sega FILM/CPK;"

                 // RoQ
                         "application/octet-stream:roq:video ID Software Game;"
                                 */
                 // PVA
                 "video/x-pva:pva:PVA;"

                 // Matroska
                 "video/x-matroska:mkv:Matroska Video;"

                 // VivoActive video file file format
                 "video/vivo:viv, vivo:VivoActive;"
                 "video/vnd.vivo:viv, vivo:VivoActive;"
               )
public:
    RosampPluginSmp(QWidget *parent = 0);
    ~RosampPluginSmp();
};


#endif // ROSAMPPLUGINSMP_H
