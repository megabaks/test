#!/bin/sh

tar --gzip -c translations romp rosamp-plugin rosa-media-player-plugin.pro >rosa-media-player-plugin-1.6.tar.gz
rm ~/rpmbuild/SOURCES/rosa-media-player-plugin-1.6.tar.gz
rpm -ba rosa-media-player-plugin.spec