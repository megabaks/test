/*  ROSA Media Player
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2013 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef VIDEOSEARCH_H
#define VIDEOSEARCH_H

#include <QtGui/QWidget>
#include <QtCore/QUrl>

#include "youtube/ytdownloadmanager.h"

#include "ui_videosearch.h"


namespace Ui
{
class VideoSearchPanel;
}

class RequestManager;
class Reply;
class YTVideoItem;
class YTVideoItemModel;
class RemoteImageLoader;
class Core;
class Playlist;
class MyAction;
class RetrieveYoutubeUrl;
class YTDownloadManager;

class VideoSearch : public QWidget
{
    Q_OBJECT
public:
    explicit VideoSearch(Core *core, Playlist *playlist, QWidget *parent = 0);
    ~VideoSearch();
    
signals:
    void stopDownloading();
    
protected slots:
    void gotVideoItems(QList<YTVideoItem *> items);
    void onReturnPressed();
    void onItemClicked(QModelIndex index);
    void onSliderMoved(int value);
    void gotVideoThumbnail(QUrl url, QImage image);
    void showContextMenu(const QPoint &pos);

    void playVideo();
    void addToPlaylist();
    void openBrowser();
    void clearVideoList();
    void searchMore();

    void startDownload(const QModelIndex &index);
    void startDownload(const QString &url);

    void stopDownload(const QModelIndex &index);
    void updateProgress(int pos);
    void downloadFinished();
    void downloadError(YTDownloadManager::Error err);

protected:
    Reply *videoUrl(const QString &searchVideo, int index);
    void getVideo(const QString &searchVideo, int index = 0);
    void retranslateStrings();

    int indexFromHash(YTDownloadManager* manager);

    void createActions();

    virtual void changeEvent(QEvent *event);

private:
    Ui::VideoSearchPanel* ui;

    RequestManager *m_requestManager;
    YTVideoItemModel *m_videoModel;
    RemoteImageLoader *m_imageLoader;
    Core *m_core;
    Playlist *m_playlist;
    RetrieveYoutubeUrl *m_yt;

    MyAction *m_playAct;
    MyAction *m_addPlaylistAct;
    MyAction *m_openBrowserAct;

    QHash<YTDownloadManager*, QString> m_hash;

};

#endif // VIDEOSEARCH_H
