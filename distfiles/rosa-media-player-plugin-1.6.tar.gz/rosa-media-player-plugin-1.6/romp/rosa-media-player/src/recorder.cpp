/*  ROSA Media Player
    Julia Mineeva, Evgeniy Augin, Sergey Borovkov. Copyright (c) 2011 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "recorder.h"

#include <QtCore/QFile>
#include <QtCore/QStringList>
#include <QtCore/QTimer>
#include <QtCore/QtDebug>
#include <QtCore/QTime>
#include <QtCore/QFileInfo>
#include <QtCore/QSettings>
#include <stdlib.h>

#ifndef Q_OS_WIN
#include <unistd.h>
#endif

#include "preferences.h"
#include "global.h"

using namespace Global;

Recorder::Recorder(QObject *parent)
    : QObject(parent)
    , m_isRecording(false)
    , m_isStopRecording(false)
    , m_timer(new QTimer(this))
{
    connect(&m_process, SIGNAL(error(QProcess::ProcessError)), SLOT(handleError(QProcess::ProcessError)));
}

void Recorder::startRecording(const RecordingOptions &options)
{
    m_isStopRecording = false;

#ifndef Q_OS_WIN
    // get analog audio sources
    QStringList sources = getAudioSources();

    const QString name = "ffmpeg";
    const QString resolution = QString::number(options.width) + "x" + QString::number(options.height);
    QStringList arguments;

    // before starting record screencast need set default source for pulseaudio
    if (options.audioDevice != 0) { // with audio

        QProcess pacmd;
        if (options.audioDevice == 2)  { // line-out
            // need restart pulse
            QProcess pulse;
            pulse.start("pulseaudio", QStringList() << "-k");
            pulse.waitForFinished();

            // add delay for restart pulse
            sleep(1);

            if (!sources.filter(QRegExp(".analog-stereo.monitor$")).isEmpty()) {
                pacmd.start("pacmd", QStringList() << "set-default-source" << sources.filter(QRegExp(".analog-stereo.monitor$")).at(0));
            }
        }
        else if (options.audioDevice == 1) { // microphone
            if (!sources.filter(QRegExp(".analog-stereo$")).isEmpty()) {
                pacmd.start("pacmd", QStringList() << "set-default-source" << sources.filter(QRegExp(".analog-stereo$")).at(0));
            }
        }
        pacmd.waitForFinished();

        // set arguments for recording with sound
        arguments << "-f" << "alsa" << "-ac" << "2" << "-i" << "default";
    }
    QString displayName(getenv("DISPLAY"));

    // ex.:  ffmpeg -f x11grab -s 1600x900 -i :0.0 -vcodec libvpx -b 5000000 out.webm
    arguments << "-f" << "x11grab" << "-s" << resolution
              << "-i"  << displayName << "-vcodec" << "libvpx" << "-b" << "5000000"
              << options.path;
    bool shouldOverwrite = false;

    if(QFile::exists(options.path))
        shouldOverwrite = true;

    qDebug() << "Starting video recording";

    m_process.setProcessChannelMode(QProcess::MergedChannels);
    m_process.start(name, arguments);

    connect(m_timer, SIGNAL(timeout()), SLOT(timeout()));
    m_timer->start(500);

    if (shouldOverwrite) {
        m_process.waitForStarted();
        m_process.write("y\n");
        m_process.waitForBytesWritten();
    }
#else
    QStringList arguments;
    QString name = pref->ffmpeg_bin;
    QFileInfo fi(name);
    if (fi.exists() && fi.isExecutable() && !fi.isDir()) {
        name = fi.absoluteFilePath();
    }

   // ex.:   ffmpeg -f dshow -i video="UScreenCapture" output.flv
    arguments << "-f" << "dshow" << "-i" << "video=UScreenCapture";

    // record with audio
    if (!options.audioDeviceName.isEmpty()) {
        arguments << "-f" << "dshow" << "-i" << ("audio=" + options.audioDeviceName + "");
    }
    arguments << options.path;

    bool shouldOverwrite = false;

    if(QFile::exists(options.path))
        shouldOverwrite = true;

    qDebug() << "Starting video recording";

    m_process.setProcessChannelMode(QProcess::MergedChannels);
    m_process.start(name, arguments);

    connect(m_timer, SIGNAL(timeout()), SLOT(timeout()));
    m_timer->start(500);

    if (shouldOverwrite) {
        m_process.waitForStarted();
        m_process.write("y\n\r");
        m_process.waitForBytesWritten();
    }
#endif

    m_isRecording = true;
}


QStringList Recorder::getAudioSources()
{
    // ex.: pactl list sources | grep -A2 'Источник #' | grep 'Имя: ' | cut -d" " -f2
    QString scriptText = QString("pactl list sources | grep -A2 '%1'| grep '%2'| cut -d\" \" -f2").arg(tr("Source #")).arg(tr("Name: "));
    QProcess pactl;
    pactl.start("sh", QStringList() << "-c" << scriptText);
    if (!pactl.waitForStarted()) {
        return QStringList();
    }
    pactl.waitForFinished();
    QByteArray result = pactl.readAllStandardOutput();
    return QString(result).split("\n").filter(QRegExp("analog-stereo"));
}

void Recorder::stopRecording()
{
    qDebug() << "Stopping video recording (wait 1.7 secs)" << QTime::currentTime().toString("hh:mm:ss");
//    if(m_isRecording)
    {
        m_process.write("q\n\r");
        m_process.closeWriteChannel();
        m_process.waitForFinished();
        m_isRecording = false;
        m_timer->stop();
        // wait 1700 msecs for stopping recording
        m_isStopRecording = true;
        m_timer->start(1700);
    }
}

bool Recorder::isRecording() const
{
    return m_isRecording;
}

void Recorder::handleError(QProcess::ProcessError err)
{
    QString errorMessage;
    switch (err) {
        case QProcess::FailedToStart:
            errorMessage = tr("Failed to start recording. Please check that ffmpeg is installed.");
            break;
        case QProcess::UnknownError:
            errorMessage = tr("Unknown error in recording occured");
            break;
        default:
            errorMessage = tr("Sorry, recording crashed");
            break;
    }

    m_isRecording = false;
    emit error(errorMessage);
}

void Recorder::timeout()
{
    if (m_isRecording) {
        QString s = m_process.readAll();
        parseOutput(s);
    }

    if (m_isStopRecording) {
        qDebug() << "Stopping video recording..." << QTime::currentTime().toString("hh:mm:ss");
        m_process.write("q");
        m_process.closeWriteChannel();
        m_process.waitForFinished();
        m_timer->stop();
        m_isStopRecording = false;
    }
}

void Recorder::parseOutput(const QString &output)
{
    // output example:
    // "frame=   89 fps=  6 q=0.0 size=    3239kB time=00:00:14.36 bitrate=1848.0kbits/s    "

    QRegExp rx("size=\\s+(.*)\\s+time=(.*)\\s+bitrate");
    rx.indexIn(output);

    if(rx.captureCount() != 2)
        return;
    else {
        QString size = rx.cap(1).trimmed();
        size.insert(size.length() - 2, " ");

        if(!rx.cap(2).isEmpty() && !size.isEmpty())
            emit recordChanged(rx.cap(2), size);
    }
}
