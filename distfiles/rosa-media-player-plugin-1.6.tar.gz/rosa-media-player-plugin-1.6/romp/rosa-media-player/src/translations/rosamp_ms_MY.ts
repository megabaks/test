<?xml version="1.0" ?><!DOCTYPE TS><TS language="ms_MY" version="2.0">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>The following people have contributed with translations:</source>
        <translation>Orang-orang ini telah menyumbang kepada penterjemahan:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="174"/>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="175"/>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Italian</source>
        <translation>Bahasa Itali</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>French</source>
        <translation>Perancis</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="249"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 dan %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="183"/>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Russian</source>
        <translation>Bahasa Russia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="246"/>
        <source>%1 and %2</source>
        <translation>%1 dan %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="185"/>
        <source>Hungarian</source>
        <translation>Bahasa Hungary</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="93"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Versi %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="99"/>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation>(c) ROSA 2011-2012

ROSA Media Player adalah perisian percuma.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Polish</source>
        <translation>Bahasa Poland</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="191"/>
        <source>Japanese</source>
        <translation>Bahasa Jepun</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Dutch</source>
        <translation>Bahasa Belanda</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Ukrainian</source>
        <translation>Bahasa Ukrain</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="199"/>
        <source>Portuguese - Brazil</source>
        <translation>Bahasa Portugis - Brazil</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="200"/>
        <source>Georgian</source>
        <translation>Bahasa Georgia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Czech</source>
        <translation>Bahasa Czech</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Bulgarian</source>
        <translation>Bahasa Bulgaria</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Turkish</source>
        <translation>Bahasa Turki</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Swedish</source>
        <translation>Bahasa Sweden</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Serbian</source>
        <translation>Bahasa Serbia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Traditional Chinese</source>
        <translation>Cina Tradisional</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Romanian</source>
        <translation>Bahasa Romania</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Portuguese - Portugal</source>
        <translation>Bahasa Portugis - Portugal</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Greek</source>
        <translation>Bahasa Greek</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="214"/>
        <source>Finnish</source>
        <translation>Bahasa Finland</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="267"/>
        <location filename="../about.cpp" line="279"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="303"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>About ROSA Media Player</source>
        <translation>Tentang ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../about.ui" line="84"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Droid Sans'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Droid Sans'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="215"/>
        <source>Korean</source>
        <translation>Bahasa Korea</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="216"/>
        <source>Macedonian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="217"/>
        <source>Basque</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>Using MPlayer %1</source>
        <translation>Guna MPlayer %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="100"/>
        <source>terms of use</source>
        <translation>Terma penggunaan</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="122"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation>Program ini adalah perisian percuma; anda boleh menyebarsemula dan/atau membuat perubahan ke atas program ini di bawah terma &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; seperti disiarkan di &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; samada lesen versi 3, atau (mengikut pilihan anda) sebarang versi terbaru dari itu.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="218"/>
        <source>Catalan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="219"/>
        <source>Slovenian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="220"/>
        <source>Arabic</source>
        <translation>Bahasa Arab</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="221"/>
        <source>Kurdish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="222"/>
        <source>Galician</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="252"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 dan %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 dan %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="223"/>
        <source>Vietnamese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="224"/>
        <source>Estonian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="225"/>
        <source>Lithuanian</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Name</source>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Description</source>
        <translation>Penerangan</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="219"/>
        <source>&amp;Save</source>
        <translation>&amp;Simpan</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="222"/>
        <source>&amp;Load</source>
        <translation>&amp;Muat</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="470"/>
        <location filename="../actionseditor.cpp" line="529"/>
        <source>Key files</source>
        <translation>Fail-fail kunci</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="468"/>
        <source>Choose a filename</source>
        <translation>Pilih nama fail</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="482"/>
        <source>Confirm overwrite?</source>
        <translation>Sahkan simpan atas fail sama?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="483"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="528"/>
        <source>Choose a file</source>
        <translation>Pilih fail</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="497"/>
        <location filename="../actionseditor.cpp" line="537"/>
        <source>Error</source>
        <translation>Ralat</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="498"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Fail ini tidak dapat disimpan</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="538"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Fail ini tidak dapat dimuatkan</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="226"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Tukar shortcut...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="74"/>
        <source>Audio Equalizer</source>
        <translation>Penyama Audio</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="77"/>
        <source>31.25 Hz</source>
        <translation>31.25 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>62.50 Hz</source>
        <translation>62.50 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="79"/>
        <source>125.0 Hz</source>
        <translation>125.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="80"/>
        <source>250.0 Hz</source>
        <translation>250.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>500.0 Hz</source>
        <translation>500.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>1.000 kHz</source>
        <translation>1.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>2.000 kHz</source>
        <translation>2.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>4.000 kHz</source>
        <translation>4.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>8.000 kHz</source>
        <translation>8.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>16.00 kHz</source>
        <translation>16.00 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>&amp;Apply</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>&amp;Reset</source>
        <translation>&amp;Menetapkan semula</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Set sebagai nilai-nilai lalai</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>Use the current values as default values for new videos.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="96"/>
        <source>Set all controls to zero.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="117"/>
        <source>Information</source>
        <translation>Informasi</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="118"/>
        <source>The current values have been stored to be used as default.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>&amp;Open</source>
        <translation>&amp;Buka</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtitles</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1590"/>
        <source>&amp;Browse</source>
        <translation>&amp;Layari</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Op&amp;tions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>&amp;Help</source>
        <translation>&amp;Bantuan</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1413"/>
        <source>&amp;File...</source>
        <translation>&amp;Fail...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1414"/>
        <source>D&amp;irectory...</source>
        <translation>D&amp;irektori...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1415"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Senarai main...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1418"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD dari pemacu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1419"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD dari folder...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1420"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1595"/>
        <source>&amp;Recent files</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1435"/>
        <source>P&amp;lay</source>
        <translation>M&amp;ain</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1442"/>
        <source>&amp;Pause</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>&amp;Stop</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1444"/>
        <source>&amp;Frame step</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1461"/>
        <source>&amp;Normal speed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1462"/>
        <source>&amp;Halve speed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Double speed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>Speed &amp;-10%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>Speed &amp;+10%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1531"/>
        <source>About &amp;ROSA Media Player</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1609"/>
        <source>Sp&amp;eed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1472"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1618"/>
        <source>Si&amp;ze</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1662"/>
        <location filename="../basegui.cpp" line="2868"/>
        <source>&amp;None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1663"/>
        <source>&amp;Lowpass5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1666"/>
        <source>Linear &amp;Blend</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1627"/>
        <source>&amp;Deinterlace</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1484"/>
        <source>&amp;Postprocessing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1485"/>
        <source>&amp;Autodetect phase</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Deblock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>De&amp;ring</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>Add n&amp;oise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1631"/>
        <source>F&amp;ilters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1473"/>
        <source>&amp;Equalizer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Screenshot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>&amp;Extrastereo</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Karaoke</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1688"/>
        <source>&amp;Filters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1697"/>
        <source>&amp;Stereo</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;4.0 Surround</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1699"/>
        <source>&amp;5.1 Surround</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1692"/>
        <source>&amp;Channels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1496"/>
        <source>&amp;Mute</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1497"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1498"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1499"/>
        <source>&amp;Delay -</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1500"/>
        <source>D&amp;elay +</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Select</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Load...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1711"/>
        <source>&amp;Chapter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1715"/>
        <source>&amp;Angle</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>&amp;Playlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Disabled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2884"/>
        <location filename="../basegui.cpp" line="2904"/>
        <location filename="../basegui.cpp" line="2924"/>
        <location filename="../basegui.cpp" line="2943"/>
        <location filename="../basegui.cpp" line="2972"/>
        <location filename="../basegui.cpp" line="3004"/>
        <location filename="../basegui.cpp" line="3031"/>
        <location filename="../basegui.cpp" line="3074"/>
        <source>&lt;empty&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3444"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3445"/>
        <location filename="../basegui.cpp" line="3674"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3446"/>
        <source>Playlists</source>
        <translation>Senarai main</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3447"/>
        <location filename="../basegui.cpp" line="3652"/>
        <location filename="../basegui.cpp" line="3675"/>
        <source>All files</source>
        <translation>Semua fail</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3442"/>
        <location filename="../basegui.cpp" line="3649"/>
        <location filename="../basegui.cpp" line="3672"/>
        <source>Choose a file</source>
        <translation>Pilih fail</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation>ROSA Media Player - log mplayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3506"/>
        <source>ROSA Media Player - Information</source>
        <translation>ROSA Media Player - Informasi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3507"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3607"/>
        <source>Choose a directory</source>
        <translation>Pilih direktori</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3651"/>
        <source>Subtitles</source>
        <translation>Sarikata</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3728"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4034"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>Versi MPlayer (%1) yang terpasang di sistem anda adalah versi lama. ROSA Media Player tidak boleh beroperasi dengan baik, pemilihan sarikata mungkin gagal...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4244"/>
        <source>Playing %1</source>
        <translation>Memainkan %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4247"/>
        <source>Pause</source>
        <translation>Berhenti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4250"/>
        <source>Stop</source>
        <translation>Tamatkan</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1446"/>
        <source>Play / Pause</source>
        <translation>Main / Henti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1458"/>
        <source>Pause / Frame step</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <location filename="../basegui.cpp" line="1512"/>
        <source>U&amp;nload</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1416"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Play list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="259"/>
        <source>Trim video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="260"/>
        <source>Extract audio track</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>C&amp;lose</source>
        <translation>T&amp;utup</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>Show / Hide right panel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>View &amp;info and properties...</source>
        <translation>Lihat &amp;info dan sifat-sifat...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1527"/>
        <source>P&amp;references...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1530"/>
        <source>Help &amp;Contents</source>
        <translation>Kandungan &amp;Bantuan</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1552"/>
        <source>Dec volume (2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1553"/>
        <source>Inc volume (2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1556"/>
        <source>Exit fullscreen</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1558"/>
        <source>OSD - Next level</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1559"/>
        <source>Dec contrast</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1560"/>
        <source>Inc contrast</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1561"/>
        <source>Dec brightness</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Inc brightness</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Dec hue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1564"/>
        <source>Inc hue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1565"/>
        <source>Dec saturation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1567"/>
        <source>Dec gamma</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Next audio</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Next subtitle</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Next chapter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Previous chapter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2213"/>
        <source>Capture desktop...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4834"/>
        <source>Video capture</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4835"/>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4836"/>
        <source>Start capture</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4837"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Inc saturation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>Inc gamma</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1667"/>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1664"/>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1665"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1534"/>
        <source>&amp;Next</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>Pre&amp;vious</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1417"/>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>Denoise nor&amp;mal</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1671"/>
        <source>Denoise &amp;soft</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1669"/>
        <source>Denoise o&amp;ff</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1515"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>&amp;Toggle double size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>S&amp;ize -</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1514"/>
        <source>Si&amp;ze +</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>Add &amp;black borders</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Soft&amp;ware scaling</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>Enable &amp;closed caption</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1517"/>
        <source>&amp;Forced subtitles only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Reset video equalizer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation>ROSA Media Player - log rosa-media-player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4660"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>MPlayer telah tamat secara tiba-tiba</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4661"/>
        <source>Exit code: %1</source>
        <translation>Kod keluar: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4682"/>
        <source>MPlayer failed to start.</source>
        <translation>MPlayer gagal untuk dimulakan.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4683"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4687"/>
        <source>MPlayer has crashed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4688"/>
        <source>See the log for more info.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1635"/>
        <source>&amp;Rotate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Off</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Show context menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3443"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1493"/>
        <source>E&amp;qualizer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Reset audio equalizer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1522"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>&amp;Auto</source>
        <translation>&amp;Auto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed -&amp;4%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>&amp;Speed +4%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;1%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>S&amp;peed +1%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1640"/>
        <source>Scree&amp;n</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>&amp;Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Next video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4033"/>
        <source>Warning - Using old MPlayer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4039"/>
        <source>Please, update your MPlayer.</source>
        <translation>Sila kemaskini MPlayer anda.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4041"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Next aspect ratio</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>Pre&amp;view...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1731"/>
        <source>DVD &amp;menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>DVD &amp;previous menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>DVD menu, move up</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>DVD menu, move down</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1729"/>
        <source>DVD menu, move left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1730"/>
        <source>DVD menu, move right</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1732"/>
        <source>DVD menu, select option</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1734"/>
        <source>DVD menu, mouse click</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>Set dela&amp;y...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3729"/>
        <source>Audio delay (in milliseconds):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4253"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4395"/>
        <source>Jump to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Subtitle &amp;visibility</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next wheel function</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Edit...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>Next TV channel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>Previous TV channel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1430"/>
        <source>Next radio channel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1431"/>
        <source>Previous radio channel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;TV</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1604"/>
        <source>Radi&amp;o</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <location filename="../basegui.cpp" line="1427"/>
        <source>&amp;Jump...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1366"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>Fli&amp;p image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Show filename on OSD</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Toggle deinterlacing</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="76"/>
        <source>Volume</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3078"/>
        <source>Brightness: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3095"/>
        <source>Contrast: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3111"/>
        <source>Gamma: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3127"/>
        <source>Hue: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3143"/>
        <source>Saturation: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3295"/>
        <source>Volume: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4261"/>
        <source>Zoom: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3433"/>
        <location filename="../core.cpp" line="3451"/>
        <source>Font scale: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4115"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4531"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3344"/>
        <source>Subtitle delay: %1 ms</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3364"/>
        <source>Audio delay: %1 ms</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3208"/>
        <source>Speed: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3505"/>
        <source>Subtitles on</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="3507"/>
        <source>Subtitles off</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4166"/>
        <source>Mouse wheel seeks now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4169"/>
        <source>Mouse wheel changes volume now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4172"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="4175"/>
        <source>Mouse wheel changes speed now</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="1149"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="1165"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="2798"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="2817"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../core.cpp" line="2835"/>
        <source>A-B markers cleared</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation>Informasi</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="362"/>
        <source>Welcome to ROSA Media Player</source>
        <translation>Selamat datang ke ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="414"/>
        <source>A:%1</source>
        <translation>A:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="419"/>
        <source>B:%1</source>
        <translation>B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="389"/>
        <source>&amp;Video info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="390"/>
        <source>&amp;Frame counter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="429"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation>%1x%2 %3 fps</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>Ralat MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="137"/>
        <source>OK</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation type="unfinished"><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn't possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="33"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation type="unfinished"/>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation type="unfinished"/>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Length</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Play</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="817"/>
        <location filename="../playlist.cpp" line="837"/>
        <source>Playlists</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="815"/>
        <source>Choose a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="835"/>
        <source>Choose a filename</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="849"/>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="850"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1077"/>
        <source>Multimedia</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>All files</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1075"/>
        <source>Select one or more files to open</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1139"/>
        <source>Choose a directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1364"/>
        <source>Edit name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1365"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>&amp;Load</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="345"/>
        <source>&amp;Save</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Next</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="350"/>
        <source>Pre&amp;vious</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="365"/>
        <source>Move &amp;up</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="366"/>
        <source>Move &amp;down</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>&amp;Repeat</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>S&amp;huffle</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Add &amp;current file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="375"/>
        <source>Add &amp;file(s)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="376"/>
        <source>Add &amp;directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Remove &amp;selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="380"/>
        <source>Remove &amp;all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="387"/>
        <source>Add...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="389"/>
        <source>Remove...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="393"/>
        <source>ROSA Media Player - Playlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="879"/>
        <source>Playlist modified</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="880"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>Preferences</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="76"/>
        <source>General</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="318"/>
        <source>Media settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="65"/>
        <source>&amp;Disable screensaver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="94"/>
        <source>Cha&amp;nnels by default:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="125"/>
        <location filename="../prefgeneral.cpp" line="375"/>
        <source>Main window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="133"/>
        <source>A&amp;utoresize:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="150"/>
        <source>Never</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="155"/>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="160"/>
        <source>Only after loading a new video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="183"/>
        <source>R&amp;emember position and size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="193"/>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>Instances</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="202"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="212"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Audio</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="221"/>
        <source>&amp;Volume normalization by default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Disable screensaver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="321"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="334"/>
        <source>Automatically add files to playlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="335"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="348"/>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="320"/>
        <source>Remember settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="51"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="72"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="325"/>
        <source>Close when finished</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="326"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="92"/>
        <source>2 (Stereo)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="93"/>
        <source>4 (4.0 Surround)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="94"/>
        <source>6 (5.1 Surround)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="79"/>
        <source>&amp;Pause when minimized</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="329"/>
        <source>Pause when minimized</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="364"/>
        <source>Channels by default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="58"/>
        <source>&amp;Close when finished playback</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="330"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="377"/>
        <source>Autoresize</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="378"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="381"/>
        <source>Remember position and size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="394"/>
        <source>Volume normalization by default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="365"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Switch screensaver off</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="342"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="347"/>
        <source>Avoid screensaver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="360"/>
        <source>Audio/video auto synchronization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="44"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="97"/>
        <location filename="../preferencesdialog.cpp" line="172"/>
        <source>ROSA Media Player - Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="176"/>
        <source>OK</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="177"/>
        <source>Close</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="178"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="179"/>
        <source>Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation type="unfinished"><numerusform></numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation type="unfinished"><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="444"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="94"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../recorder.cpp" line="97"/>
        <source>Unknown error in recording occured</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../recorder.cpp" line="100"/>
        <source>Sorry, recording crashed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="49"/>
        <source>/Screencast - </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="86"/>
        <source>Length: %1
Size: %2
</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="97"/>
        <source>Channel editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="98"/>
        <source>TV/Radio list</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="74"/>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Contrast</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Brightness</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Hue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Saturation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Gamma</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <source>&amp;Reset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="71"/>
        <source>Video Equalizer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="122"/>
        <source>Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="123"/>
        <source>The current values have been stored to be used as default.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>