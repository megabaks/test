#include "ytdownloadprocess.h"

#include <QApplication>
#include <QDebug>
#include <QRegExp>
#include <QStringList>

YTDownloadProcess::YTDownloadProcess(QObject *parent) :
    MyProcess(parent)
{
    connect( this, SIGNAL( lineAvailable(QByteArray)),
             this, SLOT( parseLine(QByteArray) ) );

    connect( this, SIGNAL( finished( int, QProcess::ExitStatus ) ),
             this, SLOT( processFinished( int, QProcess::ExitStatus ) ) );

    connect( this, SIGNAL( error( QProcess::ProcessError ) ),
             this, SLOT( gotError( QProcess::ProcessError) ) );
}

void YTDownloadProcess::parseLine(QByteArray ba)
{
    QString line = QString::fromLocal8Bit( ba );

    // Parse download progress
    QRegExp rx_pers("\\b\\d{1,3}%\\B");
    if ( rx_pers.indexIn( line ) != -1 )
    {
        QString pers = rx_pers.capturedTexts().at(0);
        pers.chop(1);        
        emit downloadProgress( pers.toInt());
    }
    //Parse sife of file
    QRegExp rx_size("\\: \\d{1,99} \\(");
    if ( rx_size.indexIn( line ) != -1 )
    {        
        QString size = rx_size.capturedTexts().at(0);
        size.chop(2);
        size = size.right(size.length()-2);
        emit gotSize(size.toLong());
    }
}

bool YTDownloadProcess::start()
{
    MyProcess::start();
    return waitForStarted();
}

// Called when the process is finished
void YTDownloadProcess::processFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    qDebug("YTDownloadProcess::processFinished: exitCode: %d, status: %d", exitCode, (int) exitStatus);
    if (exitStatus == QProcess::NormalExit)
        emit downloadFinished();
    emit processExited();
}

void YTDownloadProcess::gotError(QProcess::ProcessError error)
{
    qDebug("YTDownloadProcess::gotError: %d", (int) error);
    emit downloadFailed(YTDownloadManager::UnknownError);
    emit processExited();
}

