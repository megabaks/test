#ifndef YTDOWNLOADPROCESS_H
#define YTDOWNLOADPROCESS_H

#include <QObject>

#include "myprocess.h"
#include "youtube/ytdownloadmanager.h"

class YTDownloadProcess : public MyProcess
{
    Q_OBJECT
public:
    explicit YTDownloadProcess(QObject *parent = 0);
    bool start();

protected slots:
    void parseLine( QByteArray ba );
    void processFinished(int, QProcess::ExitStatus);
    void gotError(QProcess::ProcessError );
    
signals:
    void downloadProgress(int pers);
    void gotSize(long);
    void downloadFinished();
    void downloadFailed(YTDownloadManager::Error);
    void processExited();
    
public slots:
    
};

#endif // YTDOWNLOADPROCESS_H
