#ifndef SCREENCASTDIALOG_H
#define SCREENCASTDIALOG_H

#include <QDialog>

namespace Ui {
class ScreencastDialog;
}

class ScreencastDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit ScreencastDialog(QWidget *parent = 0);
    ~ScreencastDialog();

    enum AudioDeviceTypes{ NOT_RECORDING = 0, MICROPHONE, LINEOUT };

#ifndef Q_OS_WIN
public slots:
    void updateDescription(int pos);
#endif

public:
#ifndef Q_OS_WIN
    AudioDeviceTypes deviceSelected();
#else
    QString deviceSelected();
    static QStringList getDshowAudioDevices();
    void setAudioDevices(const QStringList &devs);
#endif
    
private:
    Ui::ScreencastDialog *ui;
};

#endif // SCREENCASTDIALOG_H
