#include "videoitemdelegate.h"

#include <QApplication>
#include <QtGui/QPainter>
#include <QtGui/QMouseEvent>
#include <QtCore/QTime>
#include <QtCore/QDebug>

#include "youtube/ytvideoitem.h"

#define ITEM_WIDTH      120
#define ITEM_HEIGHT     90

VideoItemDelegate::VideoItemDelegate(QObject *parent)
    : QStyledItemDelegate(parent)
    , m_isDownloading(false)
{
}

VideoItemDelegate::~VideoItemDelegate()
{
}

//alocate each item size in listview.
QSize VideoItemDelegate::sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    Q_UNUSED(option)
    Q_UNUSED(index)

    QFont font = QApplication::font();
    QFontMetrics fm(font);
    int margin = fm.height()/2;

    // calc width and height
    int w = ITEM_WIDTH + margin*2;
    int h = ITEM_HEIGHT + margin*2;

    return QSize(w, h);
}

void VideoItemDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
 {
    QStyledItemDelegate::paint(painter, option, index);

    painter->save();

    QFont font = QApplication::font();
    font.setBold(true);
    QFontMetrics fm(font);

    int margin = fm.height()/2;

    QImage pix = qvariant_cast<QImage>(index.data(YTVideoItem::SmallThumbnail));
    bool downloading = index.data(YTVideoItem::Downloading).toBool();
    bool downloaded = index.data(YTVideoItem::Downloaded).toBool();
    int progress = index.data(YTVideoItem::Progress).toInt();
    int duration = index.data(YTVideoItem::Duration).toInt();
    QString title = index.data(YTVideoItem::Title).toString() + " (" + convertSecsToStr(duration) + ")";

    if (pix.size().width() > ITEM_WIDTH || pix.size().height() > ITEM_HEIGHT)
        pix = pix.scaled(QSize(ITEM_WIDTH, ITEM_HEIGHT), Qt::KeepAspectRatio);

    QRect titleRect = option.rect;
    QRect iconRect = option.rect;
    QRect btnRect = option.rect;
    QRect successRect = option.rect;

    iconRect.setLeft(margin);
    iconRect.setWidth(ITEM_WIDTH);
    iconRect.setTop(iconRect.top() + margin);
    iconRect.setBottom(iconRect.top() + ITEM_HEIGHT);

    titleRect.setLeft(iconRect.right() + margin);
    titleRect.setTop(titleRect.top() + margin);
    titleRect.setBottom(option.rect.bottom() - 2*margin - 16);

    btnRect.setRight(option.rect.right() - margin);
    btnRect.setLeft(btnRect.right() - 16);
    btnRect.setBottom(option.rect.bottom() - margin);
    btnRect.setTop(btnRect.bottom() - 16);

    successRect.setRight(btnRect.left() - margin);
    successRect.setLeft(successRect.right() - 16);
    successRect.setTop(btnRect.top());
    successRect.setBottom(btnRect.bottom());

    painter->drawPixmap(iconRect.x(), iconRect.y(), pix.size().width(), pix.size().height(), QPixmap::fromImage(pix));
    painter->drawText(titleRect, Qt::AlignLeft|Qt::TextWordWrap, title);
    painter->drawImage(btnRect.x(), btnRect.y(), downloading ? QImage(":/icons-png/stop_download.png") : QImage(":/icons-png/download.png"));


    if (downloading) {
        QRect progressRect = option.rect;
        progressRect.setRight(btnRect.left() - margin);
        progressRect.setLeft(titleRect.left());
        progressRect.setTop(btnRect.top() + 2);
        progressRect.setHeight(12);
//        progressRect.setBottom(btnRect.bottom() - 2);

        painter->setBrush(QColor("#E8EDF0"));
        painter->setPen(QColor("#E8EDF0"));
        painter->drawRect(progressRect);

        QRect rc(progressRect);
        rc.setWidth((int)(rc.width()*progress/100));
        painter->setBrush(QColor("#CBD3DD"));
        painter->setPen(QColor("#CBD3DD"));
        painter->drawRect(rc);

        progressRect.setTop(progressRect.top() + 1);
        painter->setPen(Qt::black);
        painter->drawText(progressRect, Qt::AlignCenter|Qt::TextWordWrap, QString("%1\%").arg(progress));

        //#E8EDF0
    }

    if (downloaded) {
        painter->drawImage(successRect.x(), successRect.y(), QImage(":/icons-png/success_download.png"));
    }

    painter->restore();
}

QString convertSecsToStr(int secs)
{
    QTime tm;
    tm = tm.addSecs(secs);
    QString str = "h:mm:ss";

    if (tm.hour() == 0) {
        str = "mm:ss";
        if (tm.minute() == 0) {
            str = "ss";
            if (tm.second() < 10)
                str = "s";
        }
        else if (tm.minute() < 10)
            str = "m:ss";
    }

    return tm.toString(str);
}

bool VideoItemDelegate::editorEvent(QEvent *event, QAbstractItemModel *model, const QStyleOptionViewItem &option, const QModelIndex &index)
{
    Q_UNUSED(model)
    // Emit a signal when the icon is clicked
    if (event->type() == QEvent::MouseButtonRelease)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);

        QRect btnRect = VideoItemDelegate::buttonRect(option);

        if (btnRect.contains(mouseEvent->pos())) {
            bool downloading = index.data(YTVideoItem::Downloading).toBool();
            if (downloading)
                emit cancelClicked(index);
            else
                emit downloadClicked(index);
        }
    }
    return false;
}

QRect VideoItemDelegate::buttonRect(const QStyleOptionViewItem &option)
{
    QRect btnRect = option.rect;

    QFont font = QApplication::font();
    font.setBold(true);
    QFontMetrics fm(font);

    int margin = fm.height()/2;

    btnRect.setRight(option.rect.right() - margin);
    btnRect.setLeft(btnRect.right() - 16);
    btnRect.setBottom(option.rect.bottom() - margin);
    btnRect.setTop(btnRect.bottom() - 16);

    return btnRect;
}

#include "moc_videoitemdelegate.cpp"
