/* ROSA Media Player Plugin
 * Julia Mineeva, Evgeniy Augin. Copyright (c) 2011 ROSA  <support@rosalab.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


#include "rosamp-plugin.h"

#include "smplayercorelib.h"
//#include "helper.h"
#include "global.h"
#include "core.h"
#include "floatingwidget.h"
#include "translator.h"
#include "paths.h"

#include "minicontrolpanel.h"
#include "fullscreenwidget.h"
#include "cacheslider.h"
#include "timeslider.h"
#include "myslider.h"
#include "volumecontrol.h"
#include "waitwidget.h"
#include "version.h"

#include <QRect>
#include <QPainter>
#include <QTimer>
#include <QApplication>
#include <QClipboard>
#include <QProcess>
#include <QResizeEvent>
#include <QToolBar>
#include <QList>
#include <QtCore/QSettings>
#include <QtCore/QDebug>
#include <QCoreApplication>

int RosampPlugin::m_counterInstances = 0;

Translator * translator = 0;


RosampPlugin::RosampPlugin(QWidget* parent)
    : QMainWindow(parent)
    , m_videoWidth(0)
    , m_videoHeight(0)
    , m_miniPanel(0)
    , m_hideTimer(0)
    , m_fullScreenEnabled(false)
    , m_mini(0)
    , m_waitWidget(0)
{
    setFocusPolicy(Qt::StrongFocus);
    setAttribute(Qt::WA_DeleteOnClose);

    if (!m_counterInstances)
        Global::global_init();
    m_counterInstances++;

    Paths::setAppPath("/usr/lib/mozilla/plugins");

    // Translator
    translator = new Translator();

    // Application translations
    translator->load(QString( "" ));

    m_smplayerlib = new SmplayerCoreLib(this);
    m_core = m_smplayerlib->core();

    //Set volume value from settings
    QSettings settings("ROSA", "Rosa-Media-Player-plugin");
    m_core->setVolume(settings.value("volume/value",50).toInt());

    createMenus();
    createToolBar();
    initWaitControl();

    connect(m_mini, SIGNAL(setFullScreen()), SLOT(toggleFullScreen()));

    QPalette pal = palette();
    pal.setColor(QPalette::Window, Qt::black);
    setPalette(pal);

    setMouseTracking(true);
    m_animationLabel = new QLabel(this);
    m_animationLabel->setAlignment(Qt::AlignCenter);
    m_movie = new QMovie(":/images/ajax-loader.gif");
    m_animationLabel->setMovie(m_movie);
    setCentralWidget(m_animationLabel);
    m_movie->start();

    m_hideTimer = new QTimer(this);
    connect(m_hideTimer, SIGNAL(timeout()), SLOT(hideControlSlot()));

    connect(m_core, SIGNAL(mediaLoaded()), SLOT(mediaLoadedSlot()));
    m_smplayerlib->mplayerWindow()->hide();

    m_fullScreenWidget = new FullScreenWidget(m_menu , m_core, m_waitWidget);
    m_fullScreenWidget->hide();
    connect(m_fullScreenWidget, SIGNAL(offFullScreen()), SLOT(toggleFullScreen()));

    //Disable OSD text
    m_core->changeOSD(0);    
}

RosampPlugin::~RosampPlugin()
{    
    delete m_smplayerlib;
    delete m_hideTimer;
    delete m_waitWidget;


#ifdef USE_FLOATING_PANEL
    delete m_panel;
#endif

    delete m_mini;

    m_counterInstances--;
    if (!m_counterInstances)
        Global::global_end();

    delete translator;
}

void RosampPlugin::closeEvent(QCloseEvent * e)
{
    m_core->stop();
    e->accept();
}

void RosampPlugin::mousePressEvent(QMouseEvent* e)
{
    if (e->button() == Qt::RightButton)
        m_menu->exec(e->globalPos());
}

void RosampPlugin::mouseMoveEvent(QMouseEvent* e)
{
    Q_UNUSED(e)
    if (!m_fullScreenEnabled)
    {
#ifdef USE_FLOATING_PANEL
        QRect rect( width() / 2 - m_panel->width() / 2, (height() *9 ) / 10 - m_panel->height(), m_panel->width(), m_panel->height());
        if ( rect.contains( e->pos() ) )
        {
            m_hideTimer->stop();
            if ( !m_panel->isVisible() )
                m_panel->show();
        }
        else
        {
            if ( !m_hideTimer->isActive() )
                m_hideTimer->start( 3000 );
        }
#endif
    }
}

void RosampPlugin::setDataSourceUrl(const QString &url)
{
    m_sourceUrl = url;

#ifdef QAXSERVER
    // IE does not call our readData() if plugin is fullpage, so do it here
    if (QAxFactory::isServer() && clientSite())
    {
        TCHAR cFileName[512];
        if (URLDownloadToCacheFile(0, url.utf16(), cFileName, 512, 0, 0) == S_OK)
            readData(&QFile(QString::fromUtf16(cFileName)), QString());
    }
#endif

    if (m_core)
        m_core->open(m_sourceUrl);
}

QString RosampPlugin::dataSourceUrl() const
{
    return m_sourceUrl;
}

void RosampPlugin::setDataVideoWidth(const QString& w)
{
    m_videoWidth = w.toInt();
}

QString RosampPlugin::dataVideoWidth() const
{
    return QString::number(m_videoWidth);
}

void RosampPlugin::setDataVideoHeight(const QString& h)
{
    m_videoHeight = h.toInt();
}

QString RosampPlugin::dataVideoHeight() const
{
    return QString::number(m_videoHeight);
}

void RosampPlugin::copyUrl()
{
    QClipboard* clipboard = QApplication::clipboard();
    if (clipboard)
        clipboard->setText(m_sourceUrl);
}

void RosampPlugin::openVideo()
{
    if (m_fullScreenEnabled)
        toggleFullScreen();

    if (m_core) {
        if (m_core->state() != Core::Paused)
            m_core->pause();
    }

    double sec = m_core->mset.current_sec;

    QTime t(0, 0, 0);
    t = t.addSecs((int)sec);
    QString str = "hh:mm:ss";
    QString time = t.toString(str);

    QString program = "rosa-media-player";
    QStringList arguments;
    arguments << "-ss" << time << m_sourceUrl;

    QProcess* process = new QProcess(this);
    process->start(program, arguments);

}

void RosampPlugin::aboutPlugin()
{
    QMessageBox mb(m_smplayerlib->mplayerWindow());
    mb.setWindowTitle(tr( "ROSA Media Player Plugin"));
    mb.setText(tr( "<span style=\"font-weight:bold;font-size:14pt\">ROSA Media Player Plugin %1</span><br><br>"
                    "Copyright &copy; ROSA 2011<br>"
                    "<span style=\"font-size:8pt\">Authors: Evgeniy Augin, Julia Mineeva, Sergey Borovkov</span>" ).arg( rosampPluginVersion() ) );
    mb.addButton(tr("OK"), QMessageBox::AcceptRole);
    foreach (QAbstractButton* button, mb.buttons())
        button->setIcon(QIcon());
    mb.exec();
}

void RosampPlugin::transferComplete(const QString &url, int id, Reason r)
{
    Q_UNUSED(url);
    Q_UNUSED(id);
    Q_UNUSED(r);
}

bool RosampPlugin::readData( QIODevice* source, const QString& format )
{
    Q_UNUSED(format);
    return source->open(QIODevice::ReadOnly | QIODevice::Text);
}

bool RosampPlugin::writeData( QIODevice* target )
{
    return target->open(QIODevice::WriteOnly | QIODevice::Text);
}


void RosampPlugin::createMenus()
{
    m_menu = new QMenu( this );

    m_menu->addAction( tr( "Copy url..." ), this, SLOT( copyUrl() ) );
    m_menu->addAction( tr( "Open video in ROSA Media Player..." ), this, SLOT( openVideo() ) );
    m_menu->addAction( tr( "About &plugin..." ), this, SLOT( aboutPlugin() ) )->setShortcut( QString( "Ctrl+A" ) );

    m_menu->setStyleSheet( "QMenu {color: white; background-color: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(20, 20, 20, 255), stop:1 rgba(60, 60, 60, 255)); margin: 2px;}"
                           "QMenu::item {padding: 2px 25px 2px 20px; border: 1px solid transparent;}"
                           "QMenu::item:selected { border-color: gray; background: rgba(100, 100, 100, 150);}" );
}

void RosampPlugin::createToolBar()
{
    m_mini = new MiniControlPanel(m_core, m_smplayerlib->mplayerWindow());
    m_toolbar = new QToolBar(this);
    m_toolbar->setObjectName("toolbar");
    m_toolbar->addWidget(m_mini);
    m_toolbar->setMovable(false);
    m_toolbar->setFloatable(true);
    addToolBar(Qt::BottomToolBarArea, m_toolbar);

    m_toolbar->setStyleSheet("border:none");

    m_mini->setSliderEnabled(false);
}

void RosampPlugin::initWaitControl()
{
    m_waitWidget = new WaitWidget(this);
    m_waitWidget->hide();

    connect( m_mini, SIGNAL(isSeeking(bool)), SLOT(showWaitWidget(bool)));
}

void RosampPlugin::showWaitWidget(bool b)
{
    if (b) {
        QRect rect = m_fullScreenEnabled  ? QApplication::desktop()->screenGeometry() : geometry();
        m_waitWidget->move((rect.width() - m_waitWidget->width()) / 2, (rect.height() - m_waitWidget->height()) / 2);
        if (!m_waitWidget->isVisible())
            m_waitWidget->show();
        m_waitWidget->raise();
    }
    else
        m_waitWidget->hide();
}

void RosampPlugin::mediaLoadedSlot()
{
    if (m_smplayerlib->mplayerWindow()->isVisible())
        return;

    m_mini->setSliderEnabled(true);
    m_movie->stop();
    m_animationLabel->hide();
    setCentralWidget(m_smplayerlib->mplayerWindow());
    m_smplayerlib->mplayerWindow()->show();
    m_core->play();
    m_hideTimer->start(3000);
}

void RosampPlugin::setResolution(int size)
{
    switch (size)
    {
    case 3:
        m_core->changeZoom(1);
        break;
    case 2:
        m_core->changeZoom(0.75);
        break;
    case 1:
        m_core->changeZoom(0.5);
        break;
    }
}

void RosampPlugin::toggleFullScreen()
{
    if (!m_fullScreenEnabled) {
        const QRect rect = QApplication::desktop()->screenGeometry();

        m_smplayerlib->mplayerWindow()->setParent(m_fullScreenWidget);
        m_smplayerlib->mplayerWindow()->setGeometry(rect);
        m_smplayerlib->mplayerWindow()->lower();

        m_hideTimer->stop();

        m_mini->toggleFullScreenMode(true);
        m_mini->setParent(m_fullScreenWidget);

        m_fullScreenWidget->setControl(m_mini);
        m_fullScreenWidget->setWindowTitle(m_sourceUrl);
        m_fullScreenWidget->showFullScreen();
        m_fullScreenEnabled = true;

        hide();

        m_waitWidget->setParent(m_fullScreenWidget);
        m_waitWidget->move((rect.width() - m_waitWidget->width()) / 2, (rect.height() - m_waitWidget->height()) / 2);
        if (m_waitWidget->isVisible())
            m_waitWidget->raise();
    }
    else {
        m_smplayerlib->mplayerWindow()->setParent(this);
        setCentralWidget(m_smplayerlib->mplayerWindow());

        m_mini->toggleFullScreenMode(false);
        m_mini->setParent(this);
        m_mini->show();

        m_toolbar->addWidget(m_mini);

        m_fullScreenWidget->hide();
        m_fullScreenEnabled = false;

        m_waitWidget->setParent(this);
        m_waitWidget->move((width() - m_waitWidget->width() ) / 2, ( height() - m_waitWidget->height() ) / 2 );
        if (m_waitWidget->isVisible())
            m_waitWidget->raise();

        show();
    }
}

QTimer* RosampPlugin::hideTimer()
{
    return m_hideTimer;
}

void RosampPlugin::resizeEvent ( QResizeEvent * e)
{
    QWidget::resizeEvent(e);

#ifdef USE_FLOATING_PANEL
    m_panel->clearMask();
    m_panel->setGeometry(e->size().width() / 2 - m_panel->width() / 2,
                          (e->size().height() * 9) / 10 - m_panel->height(),
                          m_panel->width(), 70);
    m_panel->setBorderRadius(5);
#endif

    m_waitWidget->move((e->size().width() - m_waitWidget->width()) / 2, (e->size().height() - m_waitWidget->height()) / 2);
    if (m_waitWidget->isVisible())
        m_waitWidget->raise();
}

void RosampPlugin::getMessage( QString text )
{
    return;
    if (text.contains("Cache fill")) {
        text = text.mid(13, 1);
        int res = text.toInt();
        emit cachePercent(res);
    }
}
