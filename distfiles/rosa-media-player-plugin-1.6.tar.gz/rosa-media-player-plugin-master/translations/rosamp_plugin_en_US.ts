<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>RosampPlugin</name>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="248"/>
        <source>ROSA Media Player Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="249"/>
        <source>&lt;span style=&quot;font-weight:bold;font-size:14pt&quot;&gt;ROSA Media Player Plugin %1&lt;/span&gt;&lt;br&gt;&lt;br&gt;Copyright &amp;copy; ROSA 2011&lt;br&gt;&lt;span style=&quot;font-size:8pt&quot;&gt;Authors: Evgeniy Augin, Julia Mineeva, Sergey Borovkov&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="252"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="281"/>
        <source>Copy url...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="282"/>
        <source>Open video in ROSA Media Player...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rosamp-plugin/rosamp-plugin.cpp" line="283"/>
        <source>About &amp;plugin...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VolumeControl</name>
    <message>
        <location filename="../rosamp-plugin/volumecontrol.cpp" line="77"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
